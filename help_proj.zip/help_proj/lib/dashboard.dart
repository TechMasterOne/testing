import 'package:flutter/material.dart';
import 'Model/DashboardModel.dart';

class DashboardPage extends StatefulWidget {
  @override
  _DashboardPageState createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage> {
  Future<DashboardModel> dashboardData;

  @override
  void initState() {
    super.initState();

    dashboardData = loadDashboardData();
  }

  Future<DashboardModel> loadDashboardData() async {
    DashboardModel dashData = new DashboardModel();
    return dashData;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        iconTheme: IconThemeData(color: Colors.grey),
        elevation: 2.0,
        backgroundColor: Colors.white,
        title: Text('Help',
            style: TextStyle(
                color: Colors.grey,
                fontWeight: FontWeight.w700,
                fontSize: 25.0)),
      ),
      body: FutureBuilder<DashboardModel>(
        future: dashboardData,
        builder: (context, snapshot) {
          if (snapshot.hasData) {
            return Text("hello");
          } else if (snapshot.hasError) {
            return Text('${snapshot.error}');
          }

          return Center(
            child: CircularProgressIndicator(),
          );
        },
      ),
      bottomNavigationBar: Container(
        height: 55.0,
        child: BottomAppBar(
          color: Colors.white,
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: <Widget>[
              MaterialButton(
                  child: Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: <Widget>[
                    Icon(Icons.car_rental, color: Colors.grey),
                    Text("32MXL", style: TextStyle(color: Colors.grey))
                  ],
                ),
              )),
              MaterialButton(
                  child: Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: <Widget>[
                    Icon(Icons.car_repair, color: Colors.grey),
                    Text("24FT", style: TextStyle(color: Colors.grey))
                  ],
                ),
              )),
              MaterialButton(
                  child: Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: <Widget>[
                    Icon(Icons.summarize, color: Colors.grey),
                    Text("Summary", style: TextStyle(color: Colors.grey))
                  ],
                ),
              )),
              MaterialButton(
                  child: Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: <Widget>[
                    Icon(Icons.motorcycle, color: Colors.grey),
                    Text("20FT", style: TextStyle(color: Colors.grey))
                  ],
                ),
              )),
              MaterialButton(
                  child: Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: <Widget>[
                    Icon(Icons.bus_alert, color: Colors.grey),
                    Text("32SXL", style: TextStyle(color: Colors.grey))
                  ],
                ),
              )),
            ],
          ),
        ),
      ),
    );
  }
}
