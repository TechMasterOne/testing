import 'package:flutter_app_sample/Model/CountModel.dart';
import 'package:flutter_app_sample/Model/LoginUserDetailModel.dart';

class EzSession {
  static bool loginStatus;
  static String username;
  static String xsrfToken;

  static List<LoginUserDetailModel> loginUserDetail;

  static List<UserLevelModel> userLevel;

  static void setLoginStatus(bool isLoginSuccessful, String loggedinUsername) {
    loginStatus = isLoginSuccessful;
    username = loggedinUsername;
  }

  static bool isLogin() {
    return loginStatus;
  }

  static String getUserName() {
    return username;
  }

  static String getXsrfToken() {
    return xsrfToken;
  }

  static void setXsrfToken(String token) {
    xsrfToken = token;
  }

  static void addCompanies(List<CompanyCountModel> companies) {
    companies.addAll(companies);
  }

  static void clear() {
    loginStatus = false;
    username = null;
    loginUserDetail = null;
    userLevel = null;
    xsrfToken = null;
  }
}
