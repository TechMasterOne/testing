class DashboardDataJsonModel {
  Root root;

  DashboardDataJsonModel({this.root});

  DashboardDataJsonModel.fromJson(Map<String, dynamic> json) {
    root = json['root'] != null ? new Root.fromJson(json['root']) : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    if (this.root != null) {
      data['root'] = this.root.toJson();
    }
    return data;
  }
}

class Root {
  List<Row> row;

  Root({this.row});

  Root.fromJson(Map<String, dynamic> json) {
    if (json['row'] != null) {
      row = new List<Row>();
      json['row'].forEach((v) {
        row.add(new Row.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    if (this.row != null) {
      data['row'] = this.row.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class Row {
  String year;
  String month;
  String monthName;
  String dateId;
  String filter;
  String filterDisplayName;
  String numberOfTransactions;
  String totalOfTransactions;
  String totalOfCredits;
  String totalOfDebits;
  String totalExpenseViolations;
  String totalAccountsPayable;
  String totalExchangeAmount;
  String totalExchangePercentage;
  String totalFundsAvailableAmount;
  String totalOverlimitAmount;
  String totalAmountPastDue;
  String totalAmountDue;
  String numberOfAccounts;
  String numberOfOpenAccounts;
  String numberOfClosedAccounts;
  String totalAvailableCredit;
  String totalAvailableCash;
  String totalCreditLimit;
  String totalCashLimit;
  String totalMinimumPaymentDue;
  String totalCashBalance;
  String totalPastDueAmount;
  String totalPendingBalance;
  String totalCurrentPayments;
  String totalCurrentCredits;
  String totalDisputedAmount;
  String totalCTDiverted;
  String numberOfTransactionsMtm;
  String totalOfTransactionsMtm;
  String totalOfCreditsMtm;
  String totalOfDebitsMtm;
  String totalExpenseViolationsMtm;
  String totalAccountsPayableMtm;
  String totalExchangeAmountMtm;
  String totalExchangePercentageMtm;
  String totalFundsAvailableAmountMtm;
  String totalOverlimitAmountMtm;
  String totalAmountPastDueMtm;
  String totalAmountDueMtm;
  String numberOfAccountsMtm;
  String numberOfOpenAccountsMtm;
  String numberOfClosedAccountsMtm;
  String totalAvailableCreditMtm;
  String totalAvailableCashMtm;
  String totalCreditLimitMtm;
  String totalCashLimitMtm;
  String totalMinimumPaymentDueMtm;
  String totalCashBalanceMtm;
  String totalPastDueAmountMtm;
  String totalPendingBalanceMtm;
  String totalCurrentPaymentsMtm;
  String totalCurrentCreditsMtm;
  String totalDisputedAmountMtm;
  String totalCTDivertedMtm;
  String numberOfTransactionsYty;
  String totalOfTransactionsYty;
  String totalOfCreditsYty;
  String totalOfDebitsYty;
  String totalExpenseViolationsYty;
  String totalAccountsPayableYty;
  String totalExchangeAmountYty;
  String totalExchangePercentageYty;
  String totalFundsAvailableAmountYty;
  String totalOverlimitAmountYty;
  String totalAmountPastDueYty;
  String totalAmountDueYty;
  String numberOfAccountsYty;
  String numberOfOpenAccountsYty;
  String numberOfClosedAccountsYty;
  String totalAvailableCreditYty;
  String totalAvailableCashYty;
  String totalCreditLimitYty;
  String totalCashLimitYty;
  String totalMinimumPaymentDueYty;
  String totalCashBalanceYty;
  String totalPastDueAmountYty;
  String totalPendingBalanceYty;
  String totalCurrentPaymentsYty;
  String totalCurrentCreditsYty;
  String totalDisputedAmountYty;
  String totalCTDivertedYty;

  Row(
      {this.year,
      this.month,
      this.monthName,
      this.dateId,
      this.filter,
      this.filterDisplayName,
      this.numberOfTransactions,
      this.totalOfTransactions,
      this.totalOfCredits,
      this.totalOfDebits,
      this.totalExpenseViolations,
      this.totalAccountsPayable,
      this.totalExchangeAmount,
      this.totalExchangePercentage,
      this.totalFundsAvailableAmount,
      this.totalOverlimitAmount,
      this.totalAmountPastDue,
      this.totalAmountDue,
      this.numberOfAccounts,
      this.numberOfOpenAccounts,
      this.numberOfClosedAccounts,
      this.totalAvailableCredit,
      this.totalAvailableCash,
      this.totalCreditLimit,
      this.totalCashLimit,
      this.totalMinimumPaymentDue,
      this.totalCashBalance,
      this.totalPastDueAmount,
      this.totalPendingBalance,
      this.totalCurrentPayments,
      this.totalCurrentCredits,
      this.totalDisputedAmount,
      this.totalCTDiverted,
      this.numberOfTransactionsMtm,
      this.totalOfTransactionsMtm,
      this.totalOfCreditsMtm,
      this.totalOfDebitsMtm,
      this.totalExpenseViolationsMtm,
      this.totalAccountsPayableMtm,
      this.totalExchangeAmountMtm,
      this.totalExchangePercentageMtm,
      this.totalFundsAvailableAmountMtm,
      this.totalOverlimitAmountMtm,
      this.totalAmountPastDueMtm,
      this.totalAmountDueMtm,
      this.numberOfAccountsMtm,
      this.numberOfOpenAccountsMtm,
      this.numberOfClosedAccountsMtm,
      this.totalAvailableCreditMtm,
      this.totalAvailableCashMtm,
      this.totalCreditLimitMtm,
      this.totalCashLimitMtm,
      this.totalMinimumPaymentDueMtm,
      this.totalCashBalanceMtm,
      this.totalPastDueAmountMtm,
      this.totalPendingBalanceMtm,
      this.totalCurrentPaymentsMtm,
      this.totalCurrentCreditsMtm,
      this.totalDisputedAmountMtm,
      this.totalCTDivertedMtm,
      this.numberOfTransactionsYty,
      this.totalOfTransactionsYty,
      this.totalOfCreditsYty,
      this.totalOfDebitsYty,
      this.totalExpenseViolationsYty,
      this.totalAccountsPayableYty,
      this.totalExchangeAmountYty,
      this.totalExchangePercentageYty,
      this.totalFundsAvailableAmountYty,
      this.totalOverlimitAmountYty,
      this.totalAmountPastDueYty,
      this.totalAmountDueYty,
      this.numberOfAccountsYty,
      this.numberOfOpenAccountsYty,
      this.numberOfClosedAccountsYty,
      this.totalAvailableCreditYty,
      this.totalAvailableCashYty,
      this.totalCreditLimitYty,
      this.totalCashLimitYty,
      this.totalMinimumPaymentDueYty,
      this.totalCashBalanceYty,
      this.totalPastDueAmountYty,
      this.totalPendingBalanceYty,
      this.totalCurrentPaymentsYty,
      this.totalCurrentCreditsYty,
      this.totalDisputedAmountYty,
      this.totalCTDivertedYty});

  Row.fromJson(Map<String, dynamic> json) {
    year = json['year'];
    month = json['month'];
    monthName = json['monthName'];
    dateId = json['dateId'];
    filter = json['filter'];
    filterDisplayName = json['filterDisplayName'];
    numberOfTransactions = json['numberOfTransactions'];
    totalOfTransactions = json['totalOfTransactions'];
    totalOfCredits = json['totalOfCredits'];
    totalOfDebits = json['totalOfDebits'];
    totalExpenseViolations = json['totalExpenseViolations'];
    totalAccountsPayable = json['totalAccountsPayable'];
    totalExchangeAmount = json['totalExchangeAmount'];
    totalExchangePercentage = json['totalExchangePercentage'];
    totalFundsAvailableAmount = json['totalFundsAvailableAmount'];
    totalOverlimitAmount = json['totalOverlimitAmount'];
    totalAmountPastDue = json['totalAmountPastDue'];
    totalAmountDue = json['totalAmountDue'];
    numberOfAccounts = json['numberOfAccounts'];
    numberOfOpenAccounts = json['numberOfOpenAccounts'];
    numberOfClosedAccounts = json['numberOfClosedAccounts'];
    totalAvailableCredit = json['totalAvailableCredit'];
    totalAvailableCash = json['totalAvailableCash'];
    totalCreditLimit = json['totalCreditLimit'];
    totalCashLimit = json['totalCashLimit'];
    totalMinimumPaymentDue = json['totalMinimumPaymentDue'];
    totalCashBalance = json['totalCashBalance'];
    totalPastDueAmount = json['totalPastDueAmount'];
    totalPendingBalance = json['totalPendingBalance'];
    totalCurrentPayments = json['totalCurrentPayments'];
    totalCurrentCredits = json['totalCurrentCredits'];
    totalDisputedAmount = json['totalDisputedAmount'];
    totalCTDiverted = json['totalCTDiverted'];
    numberOfTransactionsMtm = json['numberOfTransactionsMtm'];
    totalOfTransactionsMtm = json['totalOfTransactionsMtm'];
    totalOfCreditsMtm = json['totalOfCreditsMtm'];
    totalOfDebitsMtm = json['totalOfDebitsMtm'];
    totalExpenseViolationsMtm = json['totalExpenseViolationsMtm'];
    totalAccountsPayableMtm = json['totalAccountsPayableMtm'];
    totalExchangeAmountMtm = json['totalExchangeAmountMtm'];
    totalExchangePercentageMtm = json['totalExchangePercentageMtm'];
    totalFundsAvailableAmountMtm = json['totalFundsAvailableAmountMtm'];
    totalOverlimitAmountMtm = json['totalOverlimitAmountMtm'];
    totalAmountPastDueMtm = json['totalAmountPastDueMtm'];
    totalAmountDueMtm = json['totalAmountDueMtm'];
    numberOfAccountsMtm = json['numberOfAccountsMtm'];
    numberOfOpenAccountsMtm = json['numberOfOpenAccountsMtm'];
    numberOfClosedAccountsMtm = json['numberOfClosedAccountsMtm'];
    totalAvailableCreditMtm = json['totalAvailableCreditMtm'];
    totalAvailableCashMtm = json['totalAvailableCashMtm'];
    totalCreditLimitMtm = json['totalCreditLimitMtm'];
    totalCashLimitMtm = json['totalCashLimitMtm'];
    totalMinimumPaymentDueMtm = json['totalMinimumPaymentDueMtm'];
    totalCashBalanceMtm = json['totalCashBalanceMtm'];
    totalPastDueAmountMtm = json['totalPastDueAmountMtm'];
    totalPendingBalanceMtm = json['totalPendingBalanceMtm'];
    totalCurrentPaymentsMtm = json['totalCurrentPaymentsMtm'];
    totalCurrentCreditsMtm = json['totalCurrentCreditsMtm'];
    totalDisputedAmountMtm = json['totalDisputedAmountMtm'];
    totalCTDivertedMtm = json['totalCTDivertedMtm'];
    numberOfTransactionsYty = json['numberOfTransactionsYty'];
    totalOfTransactionsYty = json['totalOfTransactionsYty'];
    totalOfCreditsYty = json['totalOfCreditsYty'];
    totalOfDebitsYty = json['totalOfDebitsYty'];
    totalExpenseViolationsYty = json['totalExpenseViolationsYty'];
    totalAccountsPayableYty = json['totalAccountsPayableYty'];
    totalExchangeAmountYty = json['totalExchangeAmountYty'];
    totalExchangePercentageYty = json['totalExchangePercentageYty'];
    totalFundsAvailableAmountYty = json['totalFundsAvailableAmountYty'];
    totalOverlimitAmountYty = json['totalOverlimitAmountYty'];
    totalAmountPastDueYty = json['totalAmountPastDueYty'];
    totalAmountDueYty = json['totalAmountDueYty'];
    numberOfAccountsYty = json['numberOfAccountsYty'];
    numberOfOpenAccountsYty = json['numberOfOpenAccountsYty'];
    numberOfClosedAccountsYty = json['numberOfClosedAccountsYty'];
    totalAvailableCreditYty = json['totalAvailableCreditYty'];
    totalAvailableCashYty = json['totalAvailableCashYty'];
    totalCreditLimitYty = json['totalCreditLimitYty'];
    totalCashLimitYty = json['totalCashLimitYty'];
    totalMinimumPaymentDueYty = json['totalMinimumPaymentDueYty'];
    totalCashBalanceYty = json['totalCashBalanceYty'];
    totalPastDueAmountYty = json['totalPastDueAmountYty'];
    totalPendingBalanceYty = json['totalPendingBalanceYty'];
    totalCurrentPaymentsYty = json['totalCurrentPaymentsYty'];
    totalCurrentCreditsYty = json['totalCurrentCreditsYty'];
    totalDisputedAmountYty = json['totalDisputedAmountYty'];
    totalCTDivertedYty = json['totalCTDivertedYty'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['year'] = this.year;
    data['month'] = this.month;
    data['monthName'] = this.monthName;
    data['dateId'] = this.dateId;
    data['filter'] = this.filter;
    data['filterDisplayName'] = this.filterDisplayName;
    data['numberOfTransactions'] = this.numberOfTransactions;
    data['totalOfTransactions'] = this.totalOfTransactions;
    data['totalOfCredits'] = this.totalOfCredits;
    data['totalOfDebits'] = this.totalOfDebits;
    data['totalExpenseViolations'] = this.totalExpenseViolations;
    data['totalAccountsPayable'] = this.totalAccountsPayable;
    data['totalExchangeAmount'] = this.totalExchangeAmount;
    data['totalExchangePercentage'] = this.totalExchangePercentage;
    data['totalFundsAvailableAmount'] = this.totalFundsAvailableAmount;
    data['totalOverlimitAmount'] = this.totalOverlimitAmount;
    data['totalAmountPastDue'] = this.totalAmountPastDue;
    data['totalAmountDue'] = this.totalAmountDue;
    data['numberOfAccounts'] = this.numberOfAccounts;
    data['numberOfOpenAccounts'] = this.numberOfOpenAccounts;
    data['numberOfClosedAccounts'] = this.numberOfClosedAccounts;
    data['totalAvailableCredit'] = this.totalAvailableCredit;
    data['totalAvailableCash'] = this.totalAvailableCash;
    data['totalCreditLimit'] = this.totalCreditLimit;
    data['totalCashLimit'] = this.totalCashLimit;
    data['totalMinimumPaymentDue'] = this.totalMinimumPaymentDue;
    data['totalCashBalance'] = this.totalCashBalance;
    data['totalPastDueAmount'] = this.totalPastDueAmount;
    data['totalPendingBalance'] = this.totalPendingBalance;
    data['totalCurrentPayments'] = this.totalCurrentPayments;
    data['totalCurrentCredits'] = this.totalCurrentCredits;
    data['totalDisputedAmount'] = this.totalDisputedAmount;
    data['totalCTDiverted'] = this.totalCTDiverted;
    data['numberOfTransactionsMtm'] = this.numberOfTransactionsMtm;
    data['totalOfTransactionsMtm'] = this.totalOfTransactionsMtm;
    data['totalOfCreditsMtm'] = this.totalOfCreditsMtm;
    data['totalOfDebitsMtm'] = this.totalOfDebitsMtm;
    data['totalExpenseViolationsMtm'] = this.totalExpenseViolationsMtm;
    data['totalAccountsPayableMtm'] = this.totalAccountsPayableMtm;
    data['totalExchangeAmountMtm'] = this.totalExchangeAmountMtm;
    data['totalExchangePercentageMtm'] = this.totalExchangePercentageMtm;
    data['totalFundsAvailableAmountMtm'] = this.totalFundsAvailableAmountMtm;
    data['totalOverlimitAmountMtm'] = this.totalOverlimitAmountMtm;
    data['totalAmountPastDueMtm'] = this.totalAmountPastDueMtm;
    data['totalAmountDueMtm'] = this.totalAmountDueMtm;
    data['numberOfAccountsMtm'] = this.numberOfAccountsMtm;
    data['numberOfOpenAccountsMtm'] = this.numberOfOpenAccountsMtm;
    data['numberOfClosedAccountsMtm'] = this.numberOfClosedAccountsMtm;
    data['totalAvailableCreditMtm'] = this.totalAvailableCreditMtm;
    data['totalAvailableCashMtm'] = this.totalAvailableCashMtm;
    data['totalCreditLimitMtm'] = this.totalCreditLimitMtm;
    data['totalCashLimitMtm'] = this.totalCashLimitMtm;
    data['totalMinimumPaymentDueMtm'] = this.totalMinimumPaymentDueMtm;
    data['totalCashBalanceMtm'] = this.totalCashBalanceMtm;
    data['totalPastDueAmountMtm'] = this.totalPastDueAmountMtm;
    data['totalPendingBalanceMtm'] = this.totalPendingBalanceMtm;
    data['totalCurrentPaymentsMtm'] = this.totalCurrentPaymentsMtm;
    data['totalCurrentCreditsMtm'] = this.totalCurrentCreditsMtm;
    data['totalDisputedAmountMtm'] = this.totalDisputedAmountMtm;
    data['totalCTDivertedMtm'] = this.totalCTDivertedMtm;
    data['numberOfTransactionsYty'] = this.numberOfTransactionsYty;
    data['totalOfTransactionsYty'] = this.totalOfTransactionsYty;
    data['totalOfCreditsYty'] = this.totalOfCreditsYty;
    data['totalOfDebitsYty'] = this.totalOfDebitsYty;
    data['totalExpenseViolationsYty'] = this.totalExpenseViolationsYty;
    data['totalAccountsPayableYty'] = this.totalAccountsPayableYty;
    data['totalExchangeAmountYty'] = this.totalExchangeAmountYty;
    data['totalExchangePercentageYty'] = this.totalExchangePercentageYty;
    data['totalFundsAvailableAmountYty'] = this.totalFundsAvailableAmountYty;
    data['totalOverlimitAmountYty'] = this.totalOverlimitAmountYty;
    data['totalAmountPastDueYty'] = this.totalAmountPastDueYty;
    data['totalAmountDueYty'] = this.totalAmountDueYty;
    data['numberOfAccountsYty'] = this.numberOfAccountsYty;
    data['numberOfOpenAccountsYty'] = this.numberOfOpenAccountsYty;
    data['numberOfClosedAccountsYty'] = this.numberOfClosedAccountsYty;
    data['totalAvailableCreditYty'] = this.totalAvailableCreditYty;
    data['totalAvailableCashYty'] = this.totalAvailableCashYty;
    data['totalCreditLimitYty'] = this.totalCreditLimitYty;
    data['totalCashLimitYty'] = this.totalCashLimitYty;
    data['totalMinimumPaymentDueYty'] = this.totalMinimumPaymentDueYty;
    data['totalCashBalanceYty'] = this.totalCashBalanceYty;
    data['totalPastDueAmountYty'] = this.totalPastDueAmountYty;
    data['totalPendingBalanceYty'] = this.totalPendingBalanceYty;
    data['totalCurrentPaymentsYty'] = this.totalCurrentPaymentsYty;
    data['totalCurrentCreditsYty'] = this.totalCurrentCreditsYty;
    data['totalDisputedAmountYty'] = this.totalDisputedAmountYty;
    data['totalCTDivertedYty'] = this.totalCTDivertedYty;
    return data;
  }
}
