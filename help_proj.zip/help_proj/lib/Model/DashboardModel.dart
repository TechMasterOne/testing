import 'package:flutter_app_sample/Model/CountModel.dart';
import 'package:flutter_app_sample/Model/ExpanseListModel.dart';
import 'package:flutter_app_sample/Model/ImportantInfoModel.dart';

class DashboardModel {
  CardholderCountModel cardholders;
  int alertsCount;
  int msgCount;
  int companyCount;
  int adminUsersCount;
  List<ImportantInfoModel> impInfos;

  List<ExpanseListModel> expanseList;

  DashboardModel(
      {this.cardholders,
      this.alertsCount,
      this.msgCount,
      this.companyCount,
      this.adminUsersCount});
}
