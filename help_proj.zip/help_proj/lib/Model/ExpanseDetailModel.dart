import 'ExpanseListModel.dart';

class ExpanseDetailModel {
  ExpanseListModel expanseListModel;
  List<ExpenseReportItem> expenseReportItems;
  List<ExpenseReportBasic> expenseReportBasics;
}

class ExpanseGraph {
  final int id;
  final String type;
  final double amount;

  ExpanseGraph(this.id, this.type, this.amount);
}

class ExpenseReportBasic {
  int id;
  int submitByUserID;
  int reviewByUserID;
  String status;
  String createDate;
  int costCenterID;
  String submitDate;
  String reviewDate;
  String reviewNotes;
  String paidDate;
  String lastStatusChangeDate;
  String subject;
  String notes;
  bool isLocked;
  String costCenterName;
  bool isCostCenterActive;
  String secondReviewNotes;
  int costcenterIdd;
  String lockedSince;
  String lockedByUserName;
  int lockedByUserID;
  int forAccountID;
  String cardHolderName;
  String reviewer1;
  String reviewer2;
  String accountNumber;
  int ooptotal;
  int mileagetotal;
  int reciepttotal;
  bool isEnrolled;

  ExpenseReportBasic(
      {this.id,
      this.submitByUserID,
      this.reviewByUserID,
      this.status,
      this.createDate,
      this.costCenterID,
      this.submitDate,
      this.reviewDate,
      this.reviewNotes,
      this.paidDate,
      this.lastStatusChangeDate,
      this.subject,
      this.notes,
      this.isLocked,
      this.costCenterName,
      this.isCostCenterActive,
      this.secondReviewNotes,
      this.costcenterIdd,
      this.lockedSince,
      this.lockedByUserName,
      this.lockedByUserID,
      this.forAccountID,
      this.cardHolderName,
      this.reviewer1,
      this.reviewer2,
      this.accountNumber,
      this.ooptotal,
      this.mileagetotal,
      this.reciepttotal,
      this.isEnrolled});

  ExpenseReportBasic.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    submitByUserID = json['submitByUserID'];
    reviewByUserID = json['reviewByUserID'];
    status = json['status'];
    createDate = json['createDate'];
    costCenterID = json['costCenterID'];
    submitDate = json['submitDate'];
    reviewDate = json['reviewDate'];
    reviewNotes = json['reviewNotes'];
    paidDate = json['paidDate'];
    lastStatusChangeDate = json['lastStatusChangeDate'];
    subject = json['subject'];
    notes = json['notes'];
    isLocked = json['isLocked'];
    costCenterName = json['costCenterName'];
    isCostCenterActive = json['isCostCenterActive'];
    secondReviewNotes = json['secondReviewNotes'];
    costcenterIdd = json['costcenterIdd'];
    lockedSince = json['lockedSince'];
    lockedByUserName = json['lockedByUserName'];
    lockedByUserID =
        json['lockedByUserID'] == null ? 0 : json['lockedByUserID'];
    forAccountID = json['forAccountID'];
    cardHolderName = json['cardHolderName'];
    reviewer1 = json['reviewer1'];
    reviewer2 = json['reviewer2'];
    accountNumber = json['accountNumber'];
    ooptotal = json['ooptotal'];
    mileagetotal = json['mileagetotal'];
    reciepttotal = json['reciepttotal'];
    isEnrolled = json['isEnrolled'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['submitByUserID'] = this.submitByUserID;
    data['reviewByUserID'] = this.reviewByUserID;
    data['status'] = this.status;
    data['createDate'] = this.createDate;
    data['costCenterID'] = this.costCenterID;
    data['submitDate'] = this.submitDate;
    data['reviewDate'] = this.reviewDate;
    data['reviewNotes'] = this.reviewNotes;
    data['paidDate'] = this.paidDate;
    data['lastStatusChangeDate'] = this.lastStatusChangeDate;
    data['subject'] = this.subject;
    data['notes'] = this.notes;
    data['isLocked'] = this.isLocked;
    data['costCenterName'] = this.costCenterName;
    data['isCostCenterActive'] = this.isCostCenterActive;
    data['secondReviewNotes'] = this.secondReviewNotes;
    data['costcenterIdd'] = this.costcenterIdd;
    data['lockedSince'] = this.lockedSince;
    data['lockedByUserName'] = this.lockedByUserName;
    data['lockedByUserID'] = this.lockedByUserID;
    data['forAccountID'] = this.forAccountID;
    data['cardHolderName'] = this.cardHolderName;
    data['reviewer1'] = this.reviewer1;
    data['reviewer2'] = this.reviewer2;
    data['accountNumber'] = this.accountNumber;
    data['ooptotal'] = this.ooptotal;
    data['mileagetotal'] = this.mileagetotal;
    data['reciepttotal'] = this.reciepttotal;
    data['isEnrolled'] = this.isEnrolled;
    return data;
  }
}

class ExpenseReportItem {
  int id;
  bool isIgnored;
  bool isIncluded;
  bool isManual;
  int categoryID;
  int newCategoryID;
  String memoAdded;
  String postDate;
  String transType;
  String description;
  String category;
  String paymentType;
  double amount;
  String newCategory;
  bool isMileage;
  int mileageVal;
  bool hasErrors;
  int amountSign;
  bool isSuppressed;
  bool isOldCategoryActive;
  bool isSplit;
  int noOfReciept;
  int transID;
  double splitPersonalAmount;

  ExpenseReportItem(
      {this.id,
      this.isIgnored,
      this.isIncluded,
      this.isManual,
      this.categoryID,
      this.newCategoryID,
      this.memoAdded,
      this.postDate,
      this.transType,
      this.description,
      this.category,
      this.paymentType,
      this.amount,
      this.newCategory,
      this.isMileage,
      this.mileageVal,
      this.hasErrors,
      this.amountSign,
      this.isSuppressed,
      this.isOldCategoryActive,
      this.isSplit,
      this.noOfReciept,
      this.transID,
      this.splitPersonalAmount});

  ExpenseReportItem.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    isIgnored = json['isIgnored'];
    isIncluded = json['isIncluded'];
    isManual = json['isManual'];
    categoryID = json['categoryID'];
    newCategoryID = json['newCategoryID'];
    memoAdded = json['memoAdded'];
    postDate = json['postDate'];
    transType = json['transType'];
    description = json['description'];
    category = json['category'];
    paymentType = json['paymentType'];
    amount = json['amount'];
    newCategory = json['newCategory'];
    isMileage = json['isMileage'];
    mileageVal = json['mileageVal'];
    hasErrors = json['hasErrors'];
    amountSign = json['amountSign'];
    isSuppressed = json['isSuppressed'];
    isOldCategoryActive = json['isOldCategoryActive'];
    isSplit = json['isSplit'];
    noOfReciept = json['noOfReciept'];
    transID = json['transID'];
    splitPersonalAmount = json['splitPersonalAmount'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['isIgnored'] = this.isIgnored;
    data['isIncluded'] = this.isIncluded;
    data['isManual'] = this.isManual;
    data['categoryID'] = this.categoryID;
    data['newCategoryID'] = this.newCategoryID;
    data['memoAdded'] = this.memoAdded;
    data['postDate'] = this.postDate;
    data['transType'] = this.transType;
    data['description'] = this.description;
    data['category'] = this.category;
    data['paymentType'] = this.paymentType;
    data['amount'] = this.amount;
    data['newCategory'] = this.newCategory;
    data['isMileage'] = this.isMileage;
    data['mileageVal'] = this.mileageVal;
    data['hasErrors'] = this.hasErrors;
    data['amountSign'] = this.amountSign;
    data['isSuppressed'] = this.isSuppressed;
    data['isOldCategoryActive'] = this.isOldCategoryActive;
    data['isSplit'] = this.isSplit;
    data['noOfReciept'] = this.noOfReciept;
    data['transID'] = this.transID;
    data['splitPersonalAmount'] = this.splitPersonalAmount;
    return data;
  }
}
