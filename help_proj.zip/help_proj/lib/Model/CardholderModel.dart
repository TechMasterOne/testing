class CardholderModel {
  int id;
  int userId;
  int accountId;
  String accountNumber;
  String name;
  String cardHolderName;
  String username;
  String address;
  String status;
  String level1DisplayName;
  String level2DisplayName;
  String level3DisplayName;
  bool temporaryAuthblock;
  bool tempBlock;

  CardholderModel(
      {this.id,
      this.userId,
      this.accountId,
      this.accountNumber,
      this.name,
      this.cardHolderName,
      this.username,
      this.address,
      this.status,
      this.level1DisplayName,
      this.level2DisplayName,
      this.level3DisplayName,
      this.temporaryAuthblock,
      this.tempBlock});

  CardholderModel.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    userId = json['userId'];
    accountId = json['accountId'];
    accountNumber = json['accountNumber'];
    name = json['name'];
    cardHolderName = json['cardHolderName'];
    username = json['username'];
    address = json['address'];
    status = json['status'];
    level1DisplayName = json['level1DisplayName'];
    level2DisplayName = json['level2DisplayName'];
    level3DisplayName = json['level3DisplayName'];
    temporaryAuthblock = json['temporaryAuthblock'];
    tempBlock = json['tempBlock'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['userId'] = this.userId;
    data['accountId'] = this.accountId;
    data['accountNumber'] = this.accountNumber;
    data['name'] = this.name;
    data['cardHolderName'] = this.cardHolderName;
    data['username'] = this.username;
    data['address'] = this.address;
    data['status'] = this.status;
    data['level1DisplayName'] = this.level1DisplayName;
    data['level2DisplayName'] = this.level2DisplayName;
    data['level3DisplayName'] = this.level3DisplayName;
    data['temporaryAuthblock'] = this.temporaryAuthblock;
    data['tempBlock'] = this.tempBlock;
    return data;
  }
}
