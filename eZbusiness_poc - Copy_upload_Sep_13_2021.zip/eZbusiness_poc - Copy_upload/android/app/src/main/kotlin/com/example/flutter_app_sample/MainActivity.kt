package com.example.flutter_app_sample
import io.flutter.embedding.android.FlutterFragmentActivity
import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterFragmentActivity() {

}
