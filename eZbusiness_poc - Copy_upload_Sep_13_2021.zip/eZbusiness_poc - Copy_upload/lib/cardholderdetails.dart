import 'Model/CardholderDetailModel.dart';
import 'Model/CardholderModel.dart';
import 'Service/eZBranding.dart';
import 'package:flutter/material.dart';
import 'package:requests/requests.dart';
import 'package:charts_flutter/flutter.dart' as charts;

class CardholderDetailPage extends StatefulWidget {
  CardholderDetailPage({Key key, this.cardholderModel}) : super(key: key);

  final CardholderModel cardholderModel;

  @override
  _CardholderDetailPageState createState() => _CardholderDetailPageState();
}

class _CardholderDetailPageState extends State<CardholderDetailPage> {
  CardholderModel cardholderModel;
  Future<CardholderDetailModel> expanseDetailData;
  @override
  void initState() {
    super.initState();
    cardholderModel = widget.cardholderModel;
    expanseDetailData = loadCardholderDetailModel();
  }

  Future<CardholderDetailModel> loadCardholderDetailModel() async {
    var responses = await Future.wait([
      Requests.get(
          'https://ezbusinessmanagementuat.fisglobal.com/api/CardHolder/Detail/' +
              cardholderModel.id.toString() +
              '/0',
          bodyEncoding: RequestBodyEncoding.JSON,
          timeoutSeconds: 60)
    ]);

    responses[0].raiseForStatus();
    //responses[1].raiseForStatus();

    CardholderDetailModel data = new CardholderDetailModel();
    data.cardholderModel = cardholderModel;
    data.cardholderDetail = CardholderDetail.fromJson(responses[0].json());

    return data;
  }

  List<charts.Series<CardholderGraph, int>> prepareGraphData(
      {CardholderDetail cardholderDetail}) {
    final data = [
      new CardholderGraph(1, 'Cash Limit', cardholderDetail.cashLimit),
      new CardholderGraph(2, 'Credit Limit', cardholderDetail.creditLimit),
    ];

    return [
      new charts.Series<CardholderGraph, int>(
          id: 'Sales',
          domainFn: (CardholderGraph card, _) => card.id,
          measureFn: (CardholderGraph card, _) => card.amount,
          data: data,
          labelAccessorFn: (CardholderGraph card, _) =>
              '${card.type} (${card.amount.toString()})',
          colorFn: (CardholderGraph card, _) =>
              charts.Color.fromHex(code: '#922545'))
    ];
  }

  @override
  Widget build(BuildContext context) {
    final readButton = Container(
        padding: EdgeInsets.symmetric(vertical: 16.0),
        width: MediaQuery.of(context).size.width,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: <Widget>[
            RaisedButton(
              onPressed: () => {},
              color: Colors.green,
              child: Text("Approve", style: TextStyle(color: Colors.white)),
            ),
            RaisedButton(
              onPressed: () => {},
              color: Colors.grey[600],
              child: Text("Reject", style: TextStyle(color: Colors.white)),
            )
          ],
        ));

    final bottomContent = Container(
      width: MediaQuery.of(context).size.width,
      padding: EdgeInsets.all(25.0),
      child: Center(
        child: Column(
          children: <Widget>[readButton],
        ),
      ),
    );

    return Scaffold(
        body: FutureBuilder<CardholderDetailModel>(
            future: expanseDetailData,
            builder: (context, snapshot) {
              if (snapshot.hasData) {
                return ListView(
                  children: <Widget>[
                    Stack(
                      children: <Widget>[
                        Container(
                          height: 180,
                          padding: EdgeInsets.fromLTRB(40, 0, 10, 10),
                          width: MediaQuery.of(context).size.width,
                          decoration: BoxDecoration(
                              color: EzBranding.getBrandingColor(
                                  'detail-head-bg-color',
                                  Color.fromRGBO(58, 66, 86, .9))),
                          child: Center(
                            child: Text(
                              cardholderModel.cardHolderName,
                              style: TextStyle(
                                  color: EzBranding.getBrandingColor(
                                      'detail-head-text-color', Colors.white),
                                  fontSize: 25.0),
                            ),
                          ),
                        ),
                        Positioned(
                          left: 7.0,
                          top: 23.0,
                          child: InkWell(
                            onTap: () {
                              Navigator.pop(context);
                            },
                            child: Icon(Icons.arrow_back,
                                color: EzBranding.getBrandingColor(
                                    'detail-head-text-color', Colors.white)),
                          ),
                        )
                      ],
                    ),
                    SizedBox(height: 6.0),
                    Container(
                      height: 300,
                      padding: EdgeInsets.all(20),
                      width: MediaQuery.of(context).size.width,
                      child: Center(
                        child: charts.PieChart(
                          prepareGraphData(
                              cardholderDetail: snapshot.data.cardholderDetail),
                          animate: true,
                          animationDuration: Duration(seconds: 1),
                          defaultRenderer: new charts.ArcRendererConfig(
                              arcWidth: 50,
                              arcRendererDecorators: [
                                new charts.ArcLabelDecorator()
                              ]),
                        ),
                      ),
                    ),
                    SizedBox(height: 1.0),
                    Container(
                        width: MediaQuery.of(context).size.width,
                        padding: EdgeInsets.all(15.0),
                        margin: EdgeInsets.all(5),
                        decoration: BoxDecoration(
                            border: Border.all(
                                color: EzBranding.getBrandingColor(
                                    'detail-body-list-bg-color',
                                    Colors.grey[300])),
                            borderRadius: BorderRadius.all(Radius.circular(20)),
                            color: EzBranding.getBrandingColor(
                                'detail-body-list-bg-color', Colors.grey[300])),
                        child: Center(
                            child: Column(children: <Widget>[
                          Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: <Widget>[
                                Text(
                                  'Account #',
                                  style: TextStyle(
                                      fontSize: 18.0,
                                      color: EzBranding.getBrandingColor(
                                          'detail-body-list-text-color',
                                          Colors.grey[300])),
                                  textAlign: TextAlign.left,
                                ),
                                Text(
                                  snapshot.data.cardholderModel.accountNumber,
                                  style: TextStyle(
                                      fontSize: 18.0,
                                      color: EzBranding.getBrandingColor(
                                          'detail-body-list-text-color',
                                          Colors.grey[300])),
                                  textAlign: TextAlign.right,
                                )
                              ])
                        ]))),
                    SizedBox(height: 1.0),
                    Container(
                        width: MediaQuery.of(context).size.width,
                        padding: EdgeInsets.all(15.0),
                        margin: EdgeInsets.all(5),
                        decoration: BoxDecoration(
                            border: Border.all(
                                color: EzBranding.getBrandingColor(
                                    'detail-body-list-bg-color',
                                    Colors.grey[300])),
                            borderRadius: BorderRadius.all(Radius.circular(20)),
                            color: EzBranding.getBrandingColor(
                                'detail-body-list-bg-color', Colors.grey[300])),
                        child: Center(
                            child: Column(children: <Widget>[
                          Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: <Widget>[
                                Text(
                                  'Account Type',
                                  style: TextStyle(
                                      fontSize: 18.0,
                                      color: EzBranding.getBrandingColor(
                                          'detail-body-list-text-color',
                                          Colors.grey[300])),
                                  textAlign: TextAlign.left,
                                ),
                                Text(
                                  snapshot.data.cardholderDetail.accountType,
                                  style: TextStyle(
                                      fontSize: 18.0,
                                      color: EzBranding.getBrandingColor(
                                          'detail-body-list-text-color',
                                          Colors.grey[300])),
                                  textAlign: TextAlign.right,
                                )
                              ])
                        ]))),
                    SizedBox(height: 1.0),
                    Container(
                        width: MediaQuery.of(context).size.width,
                        padding: EdgeInsets.all(15.0),
                        margin: EdgeInsets.all(5),
                        decoration: BoxDecoration(
                            border: Border.all(
                                color: EzBranding.getBrandingColor(
                                    'detail-body-list-bg-color',
                                    Colors.grey[300])),
                            borderRadius: BorderRadius.all(Radius.circular(20)),
                            color: EzBranding.getBrandingColor(
                                'detail-body-list-bg-color', Colors.grey[300])),
                        child: Center(
                            child: Column(children: <Widget>[
                          Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: <Widget>[
                                Text(
                                  'Corporation',
                                  style: TextStyle(
                                      fontSize: 18.0,
                                      color: EzBranding.getBrandingColor(
                                          'detail-body-list-text-color',
                                          Colors.grey[300])),
                                  textAlign: TextAlign.left,
                                ),
                                Text(
                                  snapshot
                                      .data.cardholderModel.level1DisplayName,
                                  style: TextStyle(
                                      fontSize: 18.0,
                                      color: EzBranding.getBrandingColor(
                                          'detail-body-list-text-color',
                                          Colors.grey[300])),
                                  textAlign: TextAlign.right,
                                )
                              ])
                        ]))),
                    SizedBox(height: 1.0),
                    Container(
                        width: MediaQuery.of(context).size.width,
                        padding: EdgeInsets.all(15.0),
                        margin: EdgeInsets.all(5),
                        decoration: BoxDecoration(
                            border: Border.all(
                                color: EzBranding.getBrandingColor(
                                    'detail-body-list-bg-color',
                                    Colors.grey[300])),
                            borderRadius: BorderRadius.all(Radius.circular(20)),
                            color: EzBranding.getBrandingColor(
                                'detail-body-list-bg-color', Colors.grey[300])),
                        child: Center(
                            child: Column(children: <Widget>[
                          Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: <Widget>[
                                Text(
                                  'Institution',
                                  style: TextStyle(
                                      fontSize: 18.0,
                                      color: EzBranding.getBrandingColor(
                                          'detail-body-list-text-color',
                                          Colors.grey[300])),
                                  textAlign: TextAlign.left,
                                ),
                                Text(
                                  snapshot
                                      .data.cardholderModel.level2DisplayName,
                                  style: TextStyle(fontSize: 18.0),
                                  textAlign: TextAlign.right,
                                )
                              ])
                        ]))),
                    SizedBox(height: 1.0),
                    Container(
                        width: MediaQuery.of(context).size.width,
                        padding: EdgeInsets.all(15.0),
                        margin: EdgeInsets.all(5),
                        decoration: BoxDecoration(
                            border: Border.all(
                                color: EzBranding.getBrandingColor(
                                    'detail-body-list-bg-color',
                                    Colors.grey[300])),
                            borderRadius: BorderRadius.all(Radius.circular(20)),
                            color: EzBranding.getBrandingColor(
                                'detail-body-list-bg-color', Colors.grey[300])),
                        child: Center(
                            child: Column(children: <Widget>[
                          Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: <Widget>[
                                Text(
                                  'Address',
                                  style: TextStyle(
                                      fontSize: 18.0,
                                      color: EzBranding.getBrandingColor(
                                          'detail-body-list-text-color',
                                          Colors.grey[300])),
                                  textAlign: TextAlign.left,
                                ),
                                Text(
                                  snapshot.data.cardholderModel.address == null
                                      ? ''
                                      : snapshot.data.cardholderModel.address,
                                  style: TextStyle(
                                      fontSize: 18.0,
                                      color: EzBranding.getBrandingColor(
                                          'detail-body-list-text-color',
                                          Colors.grey[300])),
                                  textAlign: TextAlign.right,
                                )
                              ])
                        ]))),
                    SizedBox(height: 1.0),
                    Container(
                        width: MediaQuery.of(context).size.width,
                        padding: EdgeInsets.all(15.0),
                        margin: EdgeInsets.all(5),
                        decoration: BoxDecoration(
                            border: Border.all(
                                color: EzBranding.getBrandingColor(
                                    'detail-body-list-bg-color',
                                    Colors.grey[300])),
                            borderRadius: BorderRadius.all(Radius.circular(20)),
                            color: EzBranding.getBrandingColor(
                                'detail-body-list-bg-color', Colors.grey[300])),
                        child: Center(
                            child: Column(children: <Widget>[
                          Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: <Widget>[
                                Text(
                                  'Enrollment Status',
                                  style: TextStyle(
                                      fontSize: 18.0,
                                      color: EzBranding.getBrandingColor(
                                          'detail-body-list-text-color',
                                          Colors.grey[300])),
                                  textAlign: TextAlign.left,
                                ),
                                Text(
                                  snapshot.data.cardholderDetail
                                              .isMFAEnrolled ||
                                          snapshot.data.cardholderDetail
                                              .isEnrolledBySSO
                                      ? 'Enrolled'
                                      : 'Unenrolled',
                                  style: TextStyle(
                                      fontSize: 18.0,
                                      color: EzBranding.getBrandingColor(
                                          'detail-body-list-text-color',
                                          Colors.grey[300])),
                                  textAlign: TextAlign.right,
                                )
                              ])
                        ]))),
                    SizedBox(height: 1.0),
                    Container(
                        width: MediaQuery.of(context).size.width,
                        padding: EdgeInsets.all(15.0),
                        margin: EdgeInsets.all(5),
                        decoration: BoxDecoration(
                            border: Border.all(
                                color: EzBranding.getBrandingColor(
                                    'detail-body-list-bg-color',
                                    Colors.grey[300])),
                            borderRadius: BorderRadius.all(Radius.circular(20)),
                            color: EzBranding.getBrandingColor(
                                'detail-body-list-bg-color', Colors.grey[300])),
                        child: Center(
                            child: Column(children: <Widget>[
                          Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: <Widget>[
                                Text(
                                  'Username',
                                  style: TextStyle(
                                      fontSize: 18.0,
                                      color: EzBranding.getBrandingColor(
                                          'detail-body-list-text-color',
                                          Colors.grey[300])),
                                  textAlign: TextAlign.left,
                                ),
                                Text(
                                  snapshot.data.cardholderDetail.userName,
                                  style: TextStyle(
                                      fontSize: 18.0,
                                      color: EzBranding.getBrandingColor(
                                          'detail-body-list-text-color',
                                          Colors.grey[300])),
                                  textAlign: TextAlign.right,
                                )
                              ])
                        ]))),
                    SizedBox(height: 1.0),
                    Container(
                        width: MediaQuery.of(context).size.width,
                        padding: EdgeInsets.all(15.0),
                        margin: EdgeInsets.all(5),
                        decoration: BoxDecoration(
                            border: Border.all(
                                color: EzBranding.getBrandingColor(
                                    'detail-body-list-bg-color',
                                    Colors.grey[300])),
                            borderRadius: BorderRadius.all(Radius.circular(20)),
                            color: EzBranding.getBrandingColor(
                                'detail-body-list-bg-color', Colors.grey[300])),
                        child: Center(
                            child: Column(children: <Widget>[
                          Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: <Widget>[
                                Text(
                                  'Open Date',
                                  style: TextStyle(
                                      fontSize: 18.0,
                                      color: EzBranding.getBrandingColor(
                                          'detail-body-list-text-color',
                                          Colors.grey[300])),
                                  textAlign: TextAlign.left,
                                ),
                                Text(
                                  snapshot.data.cardholderDetail.openDate
                                      .substring(0, 10),
                                  style: TextStyle(
                                      fontSize: 18.0,
                                      color: EzBranding.getBrandingColor(
                                          'detail-body-list-text-color',
                                          Colors.grey[300])),
                                  textAlign: TextAlign.right,
                                )
                              ])
                        ]))),
                    SizedBox(height: 1.0),
                    Container(
                        width: MediaQuery.of(context).size.width,
                        padding: EdgeInsets.all(15.0),
                        margin: EdgeInsets.all(5),
                        decoration: BoxDecoration(
                            border: Border.all(
                                color: EzBranding.getBrandingColor(
                                    'detail-body-list-bg-color',
                                    Colors.grey[300])),
                            borderRadius: BorderRadius.all(Radius.circular(20)),
                            color: EzBranding.getBrandingColor(
                                'detail-body-list-bg-color', Colors.grey[300])),
                        child: Center(
                            child: Column(children: <Widget>[
                          Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: <Widget>[
                                Text(
                                  'Expiration Date',
                                  style: TextStyle(
                                      fontSize: 18.0,
                                      color: EzBranding.getBrandingColor(
                                          'detail-body-list-text-color',
                                          Colors.grey[300])),
                                  textAlign: TextAlign.left,
                                ),
                                Text(
                                  snapshot.data.cardholderDetail.expirationDate
                                      .substring(0, 10),
                                  style: TextStyle(
                                      fontSize: 18.0,
                                      color: EzBranding.getBrandingColor(
                                          'detail-body-list-text-color',
                                          Colors.grey[300])),
                                  textAlign: TextAlign.right,
                                )
                              ])
                        ]))),
                    SizedBox(height: 1.0),
                    Container(
                        width: MediaQuery.of(context).size.width,
                        padding: EdgeInsets.all(15.0),
                        margin: EdgeInsets.all(5),
                        decoration: BoxDecoration(
                            border: Border.all(
                                color: EzBranding.getBrandingColor(
                                    'detail-body-list-bg-color',
                                    Colors.grey[300])),
                            borderRadius: BorderRadius.all(Radius.circular(20)),
                            color: EzBranding.getBrandingColor(
                                'detail-body-list-bg-color', Colors.grey[300])),
                        child: Center(
                            child: Column(children: <Widget>[
                          Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: <Widget>[
                                Text(
                                  'Block Reclass',
                                  style: TextStyle(
                                      fontSize: 18.0,
                                      color: EzBranding.getBrandingColor(
                                          'detail-body-list-text-color',
                                          Colors.grey[300])),
                                  textAlign: TextAlign.left,
                                ),
                                Text(
                                  snapshot.data.cardholderDetail
                                      .blockReclassDisplayName,
                                  style: TextStyle(
                                      fontSize: 18.0,
                                      color: EzBranding.getBrandingColor(
                                          'detail-body-list-text-color',
                                          Colors.grey[300])),
                                  textAlign: TextAlign.right,
                                )
                              ])
                        ]))),
                    SizedBox(height: 1.0),
                    Container(
                        width: MediaQuery.of(context).size.width,
                        padding: EdgeInsets.all(15.0),
                        margin: EdgeInsets.all(5),
                        decoration: BoxDecoration(
                            border: Border.all(
                                color: EzBranding.getBrandingColor(
                                    'detail-body-list-bg-color',
                                    Colors.grey[300])),
                            borderRadius: BorderRadius.all(Radius.circular(20)),
                            color: EzBranding.getBrandingColor(
                                'detail-body-list-bg-color', Colors.grey[300])),
                        child: Center(
                            child: Column(children: <Widget>[
                          Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: <Widget>[
                                Text(
                                  'Account Balance',
                                  style: TextStyle(
                                      fontSize: 18.0,
                                      color: EzBranding.getBrandingColor(
                                          'detail-body-list-text-color',
                                          Colors.grey[300])),
                                  textAlign: TextAlign.left,
                                ),
                                Text(
                                  snapshot.data.cardholderDetail.accountBalance
                                      .toString(),
                                  style: TextStyle(
                                      fontSize: 18.0,
                                      color: EzBranding.getBrandingColor(
                                          'detail-body-list-text-color',
                                          Colors.grey[300])),
                                  textAlign: TextAlign.right,
                                )
                              ])
                        ]))),
                    SizedBox(height: 1.0),
                    Container(
                        width: MediaQuery.of(context).size.width,
                        padding: EdgeInsets.all(15.0),
                        margin: EdgeInsets.all(5),
                        decoration: BoxDecoration(
                            border: Border.all(
                                color: EzBranding.getBrandingColor(
                                    'detail-body-list-bg-color',
                                    Colors.grey[300])),
                            borderRadius: BorderRadius.all(Radius.circular(20)),
                            color: EzBranding.getBrandingColor(
                                'detail-body-list-bg-color', Colors.grey[300])),
                        child: Column(children: <Widget>[
                          Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: <Widget>[
                                Text(
                                  'Credit Limit',
                                  style: TextStyle(
                                      fontSize: 18.0,
                                      color: EzBranding.getBrandingColor(
                                          'detail-body-list-text-color',
                                          Colors.grey[300])),
                                  textAlign: TextAlign.left,
                                ),
                                Text(
                                  snapshot.data.cardholderDetail.creditLimit
                                      .toString(),
                                  style: TextStyle(
                                      fontSize: 18.0,
                                      color: EzBranding.getBrandingColor(
                                          'detail-body-list-text-color',
                                          Colors.grey[300])),
                                  textAlign: TextAlign.right,
                                )
                              ])
                        ])),
                    SizedBox(height: 1.0),
                    Container(
                        width: MediaQuery.of(context).size.width,
                        padding: EdgeInsets.all(15.0),
                        margin: EdgeInsets.all(5),
                        decoration: BoxDecoration(
                            border: Border.all(
                                color: EzBranding.getBrandingColor(
                                    'detail-body-list-bg-color',
                                    Colors.grey[300])),
                            borderRadius: BorderRadius.all(Radius.circular(20)),
                            color: EzBranding.getBrandingColor(
                                'detail-body-list-bg-color', Colors.grey[300])),
                        child: Center(
                            child: Column(children: <Widget>[
                          Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: <Widget>[
                                Text(
                                  'Temp Credit Limit',
                                  style: TextStyle(
                                      fontSize: 18.0,
                                      color: EzBranding.getBrandingColor(
                                          'detail-body-list-text-color',
                                          Colors.grey[300])),
                                  textAlign: TextAlign.left,
                                ),
                                Text(
                                  snapshot.data.cardholderDetail
                                      .adjustedTempCreditLimit
                                      .toString(),
                                  style: TextStyle(
                                      fontSize: 18.0,
                                      color: EzBranding.getBrandingColor(
                                          'detail-body-list-text-color',
                                          Colors.grey[300])),
                                  textAlign: TextAlign.right,
                                )
                              ])
                        ]))),
                    SizedBox(height: 1.0),
                    Container(
                        width: MediaQuery.of(context).size.width,
                        padding: EdgeInsets.all(15.0),
                        margin: EdgeInsets.all(5),
                        decoration: BoxDecoration(
                            border: Border.all(
                                color: EzBranding.getBrandingColor(
                                    'detail-body-list-bg-color',
                                    Colors.grey[300])),
                            borderRadius: BorderRadius.all(Radius.circular(20)),
                            color: EzBranding.getBrandingColor(
                                'detail-body-list-bg-color', Colors.grey[300])),
                        child: Column(children: <Widget>[
                          Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: <Widget>[
                                Text(
                                  'Available Credit',
                                  style: TextStyle(
                                      fontSize: 18.0,
                                      color: EzBranding.getBrandingColor(
                                          'detail-body-list-text-color',
                                          Colors.grey[300])),
                                  textAlign: TextAlign.left,
                                ),
                                Text(
                                  snapshot.data.cardholderDetail.availableCredit
                                      .toString(),
                                  style: TextStyle(
                                      fontSize: 18.0,
                                      color: EzBranding.getBrandingColor(
                                          'detail-body-list-text-color',
                                          Colors.grey[300])),
                                  textAlign: TextAlign.right,
                                )
                              ])
                        ])),
                    SizedBox(height: 1.0),
                    SizedBox(height: 1.0),
                    Container(
                        width: MediaQuery.of(context).size.width,
                        padding: EdgeInsets.all(15.0),
                        margin: EdgeInsets.all(5),
                        decoration: BoxDecoration(
                            border: Border.all(
                                color: EzBranding.getBrandingColor(
                                    'detail-body-list-bg-color',
                                    Colors.grey[300])),
                            borderRadius: BorderRadius.all(Radius.circular(20)),
                            color: EzBranding.getBrandingColor(
                                'detail-body-list-bg-color', Colors.grey[300])),
                        child: Column(children: <Widget>[
                          Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: <Widget>[
                                Text(
                                  'Cash Limit',
                                  style: TextStyle(
                                      fontSize: 18.0,
                                      color: EzBranding.getBrandingColor(
                                          'detail-body-list-text-color',
                                          Colors.grey[300])),
                                  textAlign: TextAlign.left,
                                ),
                                Text(
                                  snapshot.data.cardholderDetail.cashLimit
                                      .toString(),
                                  style: TextStyle(
                                      fontSize: 18.0,
                                      color: EzBranding.getBrandingColor(
                                          'detail-body-list-text-color',
                                          Colors.grey[300])),
                                  textAlign: TextAlign.right,
                                )
                              ])
                        ])),
                    Container(
                        width: MediaQuery.of(context).size.width,
                        padding: EdgeInsets.all(15.0),
                        margin: EdgeInsets.all(5),
                        decoration: BoxDecoration(
                            border: Border.all(
                                color: EzBranding.getBrandingColor(
                                    'detail-body-list-bg-color',
                                    Colors.grey[300])),
                            borderRadius: BorderRadius.all(Radius.circular(20)),
                            color: EzBranding.getBrandingColor(
                                'detail-body-list-bg-color', Colors.grey[300])),
                        child: Column(children: <Widget>[
                          Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: <Widget>[
                                Text(
                                  'Available Cash',
                                  style: TextStyle(
                                      fontSize: 18.0,
                                      color: EzBranding.getBrandingColor(
                                          'detail-body-list-text-color',
                                          Colors.grey[300])),
                                  textAlign: TextAlign.left,
                                ),
                                Text(
                                  snapshot.data.cardholderDetail.availableCash
                                      .toString(),
                                  style: TextStyle(
                                      fontSize: 18.0,
                                      color: EzBranding.getBrandingColor(
                                          'detail-body-list-text-color',
                                          Colors.grey[300])),
                                  textAlign: TextAlign.right,
                                )
                              ])
                        ])),
                    SizedBox(height: 1.0),
                    Container(
                        width: MediaQuery.of(context).size.width,
                        padding: EdgeInsets.all(15.0),
                        margin: EdgeInsets.all(5),
                        decoration: BoxDecoration(
                            border: Border.all(
                                color: EzBranding.getBrandingColor(
                                    'detail-body-list-bg-color',
                                    Colors.grey[300])),
                            borderRadius: BorderRadius.all(Radius.circular(20)),
                            color: EzBranding.getBrandingColor(
                                'detail-body-list-bg-color', Colors.grey[300])),
                        child: Column(children: <Widget>[
                          Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: <Widget>[
                                Text(
                                  'Minimum Payment Due',
                                  style: TextStyle(
                                      fontSize: 18.0,
                                      color: EzBranding.getBrandingColor(
                                          'detail-body-list-text-color',
                                          Colors.grey[300])),
                                  textAlign: TextAlign.left,
                                ),
                                Text(
                                  snapshot
                                      .data.cardholderDetail.minimumPaymentDue
                                      .toString(),
                                  style: TextStyle(
                                      fontSize: 18.0,
                                      color: EzBranding.getBrandingColor(
                                          'detail-body-list-text-color',
                                          Colors.grey[300])),
                                  textAlign: TextAlign.right,
                                )
                              ])
                        ])),
                  ],
                );
              } else {
                return Center(
                  child: CircularProgressIndicator(),
                );
              }
            }));
  }
}
