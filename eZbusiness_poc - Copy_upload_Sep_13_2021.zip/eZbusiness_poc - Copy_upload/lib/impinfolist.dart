import 'package:flutter/material.dart';
import 'package:flutter_app_sample/Model/ImportantInfoModel.dart';
import 'package:flutter_app_sample/Service/eZSession.dart';
import 'package:flutter_app_sample/impinfodetails.dart';
import 'Service/eZBranding.dart';
//void main() => runApp(new MyApp());

class ImpInfoListPage extends StatelessWidget {
  final List<ImportantInfoModel> impInfos;

  ImpInfoListPage({Key key, this.impInfos}) : super(key: key);

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    /*
    return new MaterialApp(
      title: 'Flutter Demo',
      theme: new ThemeData(
          primaryColor: Color.fromRGBO(58, 66, 86, 1.0), fontFamily: 'Raleway'),
      home: new ListPage(title: 'Lessons'),
      // home: DetailPage(),
    );
    */

    return Scaffold(
        appBar: AppBar(
          iconTheme: IconThemeData(
              color: EzBranding.getBrandingColor(
                  'app-bar-font-color', Colors.white)),
          elevation: 2.0,
          backgroundColor:
              EzBranding.getBrandingColor('app-bar-bg-color', Colors.pink[900]),
          title: Text('Alerts',
              style: TextStyle(
                  color: EzBranding.getBrandingColor(
                      'app-bar-font-color', Colors.white),
                  fontWeight: FontWeight.w700,
                  fontSize: 25.0)),
          actions: <Widget>[
            Container(
              margin: EdgeInsets.only(right: 8.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: <Widget>[
                  Text(EzSession.getUserName(),
                      style: TextStyle(
                          color: EzBranding.getBrandingColor(
                              'app-bar-font-color', Colors.white),
                          fontWeight: FontWeight.w700,
                          fontSize: 14.0)),
                  Icon(Icons.arrow_drop_down,
                      color: EzBranding.getBrandingColor(
                          'app-bar-font-color', Colors.white))
                ],
              ),
            )
          ],
        ),
        body: ListPage(title: 'Alerts', impInfos: impInfos));
  }
}

class ListPage extends StatefulWidget {
  ListPage({Key key, this.title, this.impInfos}) : super(key: key);

  final String title;
  final List<ImportantInfoModel> impInfos;

  @override
  _ListPageState createState() => _ListPageState();
}

class _ListPageState extends State<ListPage> {
  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    ListTile makeListTile(ImportantInfoModel impinfo) => ListTile(
          contentPadding:
              EdgeInsets.symmetric(horizontal: 20.0, vertical: 10.0),
          leading: Container(
            padding: EdgeInsets.only(right: 12.0),
            decoration: new BoxDecoration(
                border: new Border(
                    right: new BorderSide(
                        width: 1.0,
                        color: EzBranding.getBrandingColor(
                            'list-partition-color', Colors.white24)))),
            child: Icon(Icons.notifications,
                color: EzBranding.getBrandingColor(
                    'list-text-color', Colors.white)),
          ),
          title: Text(
            impinfo.messageSubject,
            style: TextStyle(
                color: EzBranding.getBrandingColor(
                    'list-text-color', Colors.white),
                fontWeight: FontWeight.bold),
          ),
          // subtitle: Text("Intermediate", style: TextStyle(color: EzBranding.getBrandingColor('list-text-color', Colors.white))),

          subtitle: Row(
            children: <Widget>[
              Expanded(
                  flex: 1,
                  child: Container(
                    // tag: 'hero',
                    child: Text(impinfo.status,
                        style: TextStyle(
                            color: EzBranding.getBrandingColor(
                                'list-text-color', Colors.white))),
                  )),
              Expanded(
                flex: 4,
                child: Padding(
                    padding: EdgeInsets.only(left: 10.0),
                    child: Text(impinfo.sendDate.substring(0, 10),
                        style: TextStyle(
                            color: EzBranding.getBrandingColor(
                                'list-text-color', Colors.white)))),
              )
            ],
          ),
          trailing: Icon(Icons.keyboard_arrow_right,
              color:
                  EzBranding.getBrandingColor('list-text-color', Colors.white),
              size: 30.0),
          onTap: () {
            Navigator.push(
                context,
                MaterialPageRoute(
                    builder: (context) =>
                        ImpInfoDetailPage(importantInfo: impinfo)));
          },
        );

    Card makeCard(ImportantInfoModel impinfo) => Card(
          elevation: 8.0,
          margin: new EdgeInsets.symmetric(horizontal: 10.0, vertical: 6.0),
          child: Container(
            decoration: BoxDecoration(
                color: EzBranding.getBrandingColor(
                    'list-bg-color', Colors.grey[600])),
            child: makeListTile(impinfo),
          ),
        );

    final makeBody = Container(
      // decoration: BoxDecoration(color: Color.fromRGBO(58, 66, 86, 1.0)),
      child: ListView.builder(
        scrollDirection: Axis.vertical,
        shrinkWrap: true,
        itemCount: widget.impInfos.length,
        itemBuilder: (BuildContext context, int index) {
          return makeCard(widget.impInfos[index]);
        },
      ),
    );

    return Container(
      //decoration: BoxDecoration(color: Color.fromRGBO(58, 66, 86, 1.0)),
      child: ListView.builder(
        scrollDirection: Axis.vertical,
        shrinkWrap: true,
        itemCount: widget.impInfos.length,
        itemBuilder: (BuildContext context, int index) {
          return makeCard(widget.impInfos[index]);
        },
      ),
    );
  }
}
