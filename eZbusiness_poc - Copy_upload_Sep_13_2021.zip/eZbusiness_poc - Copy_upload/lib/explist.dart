import 'package:flutter/material.dart';
import 'package:flutter_app_sample/Service/eZSession.dart';
import 'expdetail.dart';
import 'Service/eZBranding.dart';
import 'Model/ExpanseListModel.dart';

//void main() => runApp(new MyApp());

class ExplistPage extends StatelessWidget {
  // This widget is the root of your application.
  final List<ExpanseListModel> expList;

  ExplistPage({Key key, this.expList}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          iconTheme: IconThemeData(
              color: EzBranding.getBrandingColor(
                  'app-bar-font-color', Colors.white)),
          elevation: 2.0,
          backgroundColor:
              EzBranding.getBrandingColor('app-bar-bg-color', Colors.pink[900]),
          title: Text('ExpMan',
              style: TextStyle(
                  color: EzBranding.getBrandingColor(
                      'app-bar-font-color', Colors.white),
                  fontWeight: FontWeight.w700,
                  fontSize: 25.0)),
          actions: <Widget>[
            Container(
              margin: EdgeInsets.only(right: 8.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: <Widget>[
                  Text(EzSession.getUserName(),
                      style: TextStyle(
                          color: EzBranding.getBrandingColor(
                              'app-bar-font-color', Colors.white),
                          fontWeight: FontWeight.w700,
                          fontSize: 14.0)),
                  Icon(Icons.arrow_drop_down,
                      color: EzBranding.getBrandingColor(
                          'app-bar-font-color', Colors.white))
                ],
              ),
            )
          ],
        ),
        body: ListPage(
          title: 'ExpMan',
          expList: expList,
        ));
  }
}

class ListPage extends StatefulWidget {
  ListPage({Key key, this.title, this.expList}) : super(key: key);

  final String title;
  final List<ExpanseListModel> expList;

  @override
  _ListPageState createState() => _ListPageState();
}

class _ListPageState extends State<ListPage> {
  List expanseListModels;

  @override
  void initState() {
    expanseListModels = widget.expList;
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    ListTile makeListTile(ExpanseListModel expanseListModel) => ListTile(
          contentPadding:
              EdgeInsets.symmetric(horizontal: 10.0, vertical: 10.0),
          leading: Container(
            padding: EdgeInsets.only(right: 12.0),
            decoration: new BoxDecoration(
                border: new Border(
                    right: new BorderSide(
                        width: 2.0,
                        color: EzBranding.getBrandingColor(
                            'list-partition-color', Colors.white24)))),
            child: Icon(Icons.receipt,
                color: EzBranding.getBrandingColor(
                    'list-text-color', Colors.white)),
          ),
          title: Row(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              Expanded(
                  flex: 4,
                  child: Text(
                    expanseListModel.subject,
                    style: TextStyle(
                        color: EzBranding.getBrandingColor(
                            'list-text-color', Colors.white),
                        fontWeight: FontWeight.bold),
                  )),
              Expanded(
                  flex: 1,
                  child: Container(
                    // tag: 'hero',
                    child: LinearProgressIndicator(
                        backgroundColor: Colors.white,
                        value: expanseListModel.status == 'Submitted'
                            ? 0.3
                            : expanseListModel.status == 'Final Approval'
                                ? 0.6
                                : 1,
                        valueColor: AlwaysStoppedAnimation(Colors.green)),
                  )),
            ],
          ),
          subtitle: Row(
            mainAxisAlignment: MainAxisAlignment.start,
            children: <Widget>[
              Expanded(
                  flex: 1,
                  child: Container(
                      child: Text(expanseListModel.cardHolderName,
                          style: TextStyle(
                              color: EzBranding.getBrandingColor(
                                  'list-text-color', Colors.white))))),
            ],
          ),
          trailing: Icon(Icons.keyboard_arrow_right,
              color:
                  EzBranding.getBrandingColor('list-text-color', Colors.white),
              size: 30.0),
          onTap: () {
            Navigator.push(
                context,
                MaterialPageRoute(
                    builder: (context) =>
                        ExpDetailPage(expanseListModel: expanseListModel)));
          },
        );

    Card makeCard(ExpanseListModel expanseListModel) => Card(
          margin: new EdgeInsets.all(6.0),
          child: Container(
            decoration: BoxDecoration(
                color: EzBranding.getBrandingColor(
                    'list-bg-color', Colors.grey[600]),
                border: Border.all(
                    color: EzBranding.getBrandingColor(
                        'list-bg-color', Colors.grey[600])),
                borderRadius: BorderRadius.all(Radius.circular(5))),
            child: makeListTile(expanseListModel),
          ),
        );

    return Container(
      decoration: BoxDecoration(color: Colors.white),
      child: ListView.builder(
        scrollDirection: Axis.vertical,
        shrinkWrap: true,
        itemCount: expanseListModels.length,
        itemBuilder: (BuildContext context, int index) {
          return makeCard(expanseListModels[index]);
        },
      ),
    );
  }
}
