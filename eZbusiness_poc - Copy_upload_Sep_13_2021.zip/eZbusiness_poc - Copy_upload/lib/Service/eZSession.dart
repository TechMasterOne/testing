import 'package:flutter_app_sample/Model/AdminUserModel.dart';
import 'package:flutter_app_sample/Model/CountModel.dart';
import 'package:flutter_app_sample/Model/LoginUserDetailModel.dart';

class EzSession {
  static bool loginStatus;
  static String username;
  static String xsrfToken;
  static List<AdminUserModel> adminUsers = new List<AdminUserModel>();
  static List<CompanyCountModel> companies = new List<CompanyCountModel>();

  static List<LoginUserDetailModel> loginUserDetail;

  static List<UserLevelModel> userLevel;

  static void setLoginStatus(bool isLoginSuccessful, String loggedinUsername) {
    loginStatus = isLoginSuccessful;
    username = loggedinUsername;
  }

  static bool isLogin() {
    return loginStatus;
  }

  static String getUserName() {
    return username;
  }

  static String getXsrfToken() {
    return xsrfToken;
  }

  static void setXsrfToken(String token) {
    xsrfToken = token;
  }

  static List<AdminUserModel> getAdminUsers() {
    return adminUsers;
  }

  static void addAdminUser(List<AdminUserModel> admins) {
    adminUsers.addAll(admins);
  }

  static List<CompanyCountModel> getCompanies() {
    return companies;
  }

  static void addCompanies(List<CompanyCountModel> companies) {
    companies.addAll(companies);
  }

  static void clear() {
    loginStatus = false;
    username = null;
    loginUserDetail = null;
    userLevel = null;
    adminUsers = new List<AdminUserModel>();
    companies = new List<CompanyCountModel>();
    xsrfToken = null;
  }
}
