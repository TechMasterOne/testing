import 'Model/ExpanseDetailModel.dart';
import 'Model/ExpanseListModel.dart';
import 'Service/eZBranding.dart';
import 'package:flutter/material.dart';
import 'package:requests/requests.dart';
import 'package:charts_flutter/flutter.dart' as charts;

class ExpDetailPage extends StatefulWidget {
  ExpDetailPage({Key key, this.expanseListModel}) : super(key: key);

  final ExpanseListModel expanseListModel;

  @override
  _ExpDetailPageState createState() => _ExpDetailPageState();
}

class _ExpDetailPageState extends State<ExpDetailPage> {
  ExpanseListModel expanseListModel;
  Future<ExpanseDetailModel> expanseDetailData;
  @override
  void initState() {
    super.initState();
    expanseListModel = widget.expanseListModel;
    expanseDetailData = loadExpanseDetailModel();
  }

  Future<ExpanseDetailModel> loadExpanseDetailModel() async {
    var responses = await Future.wait([
      Requests.get(
          'https://ezbusinessmanagementuat.fisglobal.com/api/AdminExpenseManagement/GetExpenseReportBasic/' +
              expanseListModel.id.toString() +
              '/' +
              expanseListModel.accountid.toString(),
          bodyEncoding: RequestBodyEncoding.JSON,
          timeoutSeconds: 60),
      Requests.get(
          'https://ezbusinessmanagementuat.fisglobal.com/api/AdminExpenseManagement/GetExpenseReportItems/' +
              expanseListModel.id.toString(),
          bodyEncoding: RequestBodyEncoding.JSON,
          timeoutSeconds: 60)
    ]);

    responses[0].raiseForStatus();
    responses[1].raiseForStatus();

    ExpanseDetailModel data = new ExpanseDetailModel();
    data.expanseListModel = expanseListModel;
    data.expenseReportBasics = List<ExpenseReportBasic>.from(
        responses[0].json().map((model) => ExpenseReportBasic.fromJson(model)));
    data.expenseReportItems = List<ExpenseReportItem>.from(
        responses[1].json().map((model) => ExpenseReportItem.fromJson(model)));

    return data;
  }

  List<charts.Series<ExpanseGraph, int>> prepareGraphData(
      {List<ExpenseReportItem> expReportItems}) {
    final data = expReportItems
        .map(
            (model) => new ExpanseGraph(model.id, model.category, model.amount))
        .toList();

    return [
      new charts.Series<ExpanseGraph, int>(
          id: 'Sales',
          domainFn: (ExpanseGraph card, _) => card.id,
          measureFn: (ExpanseGraph card, _) => card.amount,
          data: data,
          labelAccessorFn: (ExpanseGraph card, _) =>
              '${card.type} (${card.amount.toString()})',
          colorFn: (ExpanseGraph card, _) =>
              charts.MaterialPalette.purple.makeShades(9)[_])
    ];
  }

  @override
  Widget build(BuildContext context) {
    final levelIndicator = Container(
      child: Container(
        child: LinearProgressIndicator(
            backgroundColor: Color.fromRGBO(209, 224, 224, 0.2),
            value: expanseListModel.status == 'Submitted'
                ? 0.3
                : expanseListModel.status == 'Final Approval'
                    ? 0.6
                    : 1,
            valueColor: AlwaysStoppedAnimation(Colors.green)),
      ),
    );

    final readButton = Container(
        padding: EdgeInsets.symmetric(vertical: 16.0),
        width: MediaQuery.of(context).size.width,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: <Widget>[
            RaisedButton(
              onPressed: () => {},
              color: Colors.green,
              child: Text("Approve",
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 20,
                  )),
            ),
            RaisedButton(
              onPressed: () => {},
              color: Colors.grey[600],
              child: Text(" Reject ",
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 20,
                  )),
            )
          ],
        ));
    final bottomContent = Container(
      width: MediaQuery.of(context).size.width,
      padding: EdgeInsets.all(25.0),
      child: Center(
        child: Column(
          children: <Widget>[readButton],
        ),
      ),
    );

    Container makeTranCard(ExpenseReportItem expanseReportItem) => Container(
          child: Container(
              width: MediaQuery.of(context).size.width,
              padding: EdgeInsets.all(15.0),
              margin: EdgeInsets.all(5),
              decoration: BoxDecoration(
                  border: Border.all(
                      color: EzBranding.getBrandingColor(
                          'detail-body-list-bg-color', Colors.grey[300])),
                  borderRadius: BorderRadius.all(Radius.circular(20)),
                  color: EzBranding.getBrandingColor(
                      'detail-body-list-bg-color', Colors.grey[300])),
              child: Column(
                children: <Widget>[
                  Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: <Widget>[
                        Text(
                          'Date',
                          style: TextStyle(
                              fontSize: 18.0,
                              color: EzBranding.getBrandingColor(
                                  'detail-body-list-text-color',
                                  Colors.grey[300])),
                          textAlign: TextAlign.left,
                        ),
                        Text(
                          expanseReportItem.postDate.substring(0, 10),
                          style: TextStyle(
                              fontSize: 18.0,
                              color: EzBranding.getBrandingColor(
                                  'detail-body-list-text-color',
                                  Colors.grey[300])),
                          textAlign: TextAlign.right,
                        )
                      ]),
                  SizedBox(height: 3.0),
                  Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: <Widget>[
                        Expanded(
                            flex: 1,
                            child: Container(
                                child: Text(
                              'Transaction Type',
                              style: TextStyle(
                                  fontSize: 18.0,
                                  color: EzBranding.getBrandingColor(
                                      'detail-body-list-text-color',
                                      Colors.grey[300])),
                              textAlign: TextAlign.left,
                            ))),
                        Expanded(
                            flex: 1,
                            child: Container(
                                child: Text(
                              expanseReportItem.transType,
                              style: TextStyle(
                                  fontSize: 18.0,
                                  color: EzBranding.getBrandingColor(
                                      'detail-body-list-text-color',
                                      Colors.grey[300])),
                              textAlign: TextAlign.right,
                            )))
                      ]),
                  SizedBox(height: 3.0),
                  Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: <Widget>[
                        Text(
                          'Original Category',
                          style: TextStyle(
                              fontSize: 18.0,
                              color: EzBranding.getBrandingColor(
                                  'detail-body-list-text-color',
                                  Colors.grey[300])),
                          textAlign: TextAlign.left,
                        ),
                        Text(
                          expanseReportItem.category,
                          style: TextStyle(
                              fontSize: 18.0,
                              color: EzBranding.getBrandingColor(
                                  'detail-body-list-text-color',
                                  Colors.grey[300])),
                          textAlign: TextAlign.right,
                        )
                      ]),
                  SizedBox(height: 3.0),
                  Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: <Widget>[
                        Text(
                          'Payment Type',
                          style: TextStyle(
                              fontSize: 18.0,
                              color: EzBranding.getBrandingColor(
                                  'detail-body-list-text-color',
                                  Colors.grey[300])),
                          textAlign: TextAlign.left,
                        ),
                        Text(
                          expanseReportItem.paymentType,
                          style: TextStyle(
                              fontSize: 18.0,
                              color: EzBranding.getBrandingColor(
                                  'detail-body-list-text-color',
                                  Colors.grey[300])),
                          textAlign: TextAlign.right,
                        )
                      ]),
                  SizedBox(height: 3.0),
                  Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: <Widget>[
                        Text(
                          'Amount',
                          style: TextStyle(
                              fontSize: 18.0,
                              color: EzBranding.getBrandingColor(
                                  'detail-body-list-text-color',
                                  Colors.grey[300])),
                          textAlign: TextAlign.left,
                        ),
                        Text(
                          '\$' + expanseReportItem.amount.toString(),
                          style: TextStyle(
                              fontSize: 18.0,
                              color: EzBranding.getBrandingColor(
                                  'detail-body-list-text-color',
                                  Colors.grey[300])),
                          textAlign: TextAlign.right,
                        )
                      ]),
                ],
              )),
        );

    return Scaffold(
        body: FutureBuilder<ExpanseDetailModel>(
            future: expanseDetailData,
            builder: (context, snapshot) {
              if (snapshot.hasData) {
                return ListView(
                  children: <Widget>[
                    Stack(
                      children: <Widget>[
                        Container(
                          height: 200,
                          padding: EdgeInsets.fromLTRB(40, 0, 10, 10),
                          width: MediaQuery.of(context).size.width,
                          decoration: BoxDecoration(
                              color: EzBranding.getBrandingColor(
                                  'detail-head-bg-color',
                                  Color.fromRGBO(58, 66, 86, .9))),
                          child: Center(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: <Widget>[
                                SizedBox(height: 20.0),
                                Text(
                                  expanseListModel.subject,
                                  style: TextStyle(
                                      color: EzBranding.getBrandingColor(
                                          'detail-head-text-color',
                                          Colors.white),
                                      fontSize: 25.0),
                                ),
                                SizedBox(height: 15.0),
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  children: <Widget>[
                                    Expanded(flex: 1, child: levelIndicator),
                                    Expanded(
                                        flex: 6,
                                        child: Padding(
                                            padding:
                                                EdgeInsets.only(left: 10.0),
                                            child: Text(
                                              expanseListModel.cardHolderName,
                                              style: TextStyle(
                                                  color: EzBranding
                                                      .getBrandingColor(
                                                          'detail-head-text-color',
                                                          Colors.white)),
                                            ))),
                                  ],
                                ),
                                SizedBox(height: 10.0),
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  children: <Widget>[
                                    Expanded(
                                        flex: 1,
                                        child: Container(
                                          padding: const EdgeInsets.all(7.0),
                                          decoration: new BoxDecoration(
                                              border: new Border.all(
                                                  color: EzBranding
                                                      .getBrandingColor(
                                                          'detail-head-text-color',
                                                          Colors.white)),
                                              borderRadius:
                                                  BorderRadius.circular(5.0)),
                                          child: new Text(
                                            "Total Amount:  \$" +
                                                snapshot.data.expenseReportItems
                                                    .map((e) => e.amount)
                                                    .fold(
                                                        0,
                                                        (previousValue,
                                                                element) =>
                                                            previousValue +
                                                            element)
                                                    .toString(),
                                            style: TextStyle(
                                                color:
                                                    EzBranding.getBrandingColor(
                                                        'detail-head-text-color',
                                                        Colors.white)),
                                          ),
                                        ))
                                  ],
                                ),
                              ],
                            ),
                          ),
                        ),
                        Positioned(
                          left: 7.0,
                          top: 23.0,
                          child: InkWell(
                            onTap: () {
                              Navigator.pop(context);
                            },
                            child: Icon(Icons.arrow_back, color: Colors.white),
                          ),
                        )
                      ],
                    ),
                    SizedBox(height: 6.0),
                    Container(
                      height: 300,
                      padding: EdgeInsets.all(20),
                      width: MediaQuery.of(context).size.width,
                      child: Center(
                        child: charts.PieChart(
                          prepareGraphData(
                              expReportItems: snapshot.data.expenseReportItems),
                          animate: true,
                          animationDuration: Duration(seconds: 1),
                          defaultRenderer: new charts.ArcRendererConfig(
                              arcWidth: 50,
                              arcRendererDecorators: [
                                new charts.ArcLabelDecorator()
                              ]),
                        ),
                      ),
                    ),
                    SizedBox(height: 1.0),
                    Container(
                        width: MediaQuery.of(context).size.width,
                        padding: EdgeInsets.all(15.0),
                        margin: EdgeInsets.all(5),
                        decoration: BoxDecoration(
                            border: Border.all(
                                color: EzBranding.getBrandingColor(
                                    'detail-body-list-bg-color',
                                    Colors.grey[300])),
                            borderRadius: BorderRadius.all(Radius.circular(20)),
                            color: EzBranding.getBrandingColor(
                                'detail-body-list-bg-color', Colors.grey[300])),
                        child: Center(
                            child: Column(children: <Widget>[
                          Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: <Widget>[
                                Text(
                                  'Cardholder',
                                  style: TextStyle(
                                      fontSize: 18.0,
                                      color: EzBranding.getBrandingColor(
                                          'detail-body-list-text-color',
                                          Colors.grey[300])),
                                  textAlign: TextAlign.left,
                                ),
                                Text(
                                  snapshot.data.expenseReportBasics[0]
                                      .cardHolderName,
                                  style: TextStyle(
                                      fontSize: 18.0,
                                      color: EzBranding.getBrandingColor(
                                          'detail-body-list-text-color',
                                          Colors.grey[300])),
                                  textAlign: TextAlign.right,
                                )
                              ])
                        ]))),
                    SizedBox(height: 1.0),
                    Container(
                        width: MediaQuery.of(context).size.width,
                        padding: EdgeInsets.all(15.0),
                        margin: EdgeInsets.all(5),
                        decoration: BoxDecoration(
                            border: Border.all(
                                color: EzBranding.getBrandingColor(
                                    'detail-body-list-bg-color',
                                    Colors.grey[300])),
                            borderRadius: BorderRadius.all(Radius.circular(20)),
                            color: EzBranding.getBrandingColor(
                                'detail-body-list-bg-color', Colors.grey[300])),
                        child: Center(
                            child: Column(children: <Widget>[
                          Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: <Widget>[
                                Text(
                                  'Account',
                                  style: TextStyle(
                                      fontSize: 18.0,
                                      color: EzBranding.getBrandingColor(
                                          'detail-body-list-text-color',
                                          Colors.grey[300])),
                                  textAlign: TextAlign.left,
                                ),
                                Text(
                                  snapshot.data.expenseReportBasics[0]
                                      .accountNumber,
                                  style: TextStyle(
                                      fontSize: 18.0,
                                      color: EzBranding.getBrandingColor(
                                          'detail-body-list-text-color',
                                          Colors.grey[300])),
                                  textAlign: TextAlign.right,
                                )
                              ])
                        ]))),
                    SizedBox(height: 1.0),
                    Container(
                        width: MediaQuery.of(context).size.width,
                        padding: EdgeInsets.all(15.0),
                        margin: EdgeInsets.all(5),
                        decoration: BoxDecoration(
                            border: Border.all(
                                color: EzBranding.getBrandingColor(
                                    'detail-body-list-bg-color',
                                    Colors.grey[300])),
                            borderRadius: BorderRadius.all(Radius.circular(20)),
                            color: EzBranding.getBrandingColor(
                                'detail-body-list-bg-color', Colors.grey[300])),
                        child: Center(
                            child: Column(children: <Widget>[
                          Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: <Widget>[
                                Text(
                                  'Status',
                                  style: TextStyle(
                                      fontSize: 18.0,
                                      color: EzBranding.getBrandingColor(
                                          'detail-body-list-text-color',
                                          Colors.grey[300])),
                                  textAlign: TextAlign.left,
                                ),
                                Text(
                                  snapshot.data.expenseReportBasics[0].status,
                                  style: TextStyle(
                                      fontSize: 18.0,
                                      color: EzBranding.getBrandingColor(
                                          'detail-body-list-text-color',
                                          Colors.grey[300])),
                                  textAlign: TextAlign.right,
                                )
                              ])
                        ]))),
                    SizedBox(height: 1.0),
                    Container(
                        width: MediaQuery.of(context).size.width,
                        padding: EdgeInsets.all(15.0),
                        margin: EdgeInsets.all(5),
                        decoration: BoxDecoration(
                            border: Border.all(
                                color: EzBranding.getBrandingColor(
                                    'detail-body-list-bg-color',
                                    Colors.grey[300])),
                            borderRadius: BorderRadius.all(Radius.circular(20)),
                            color: EzBranding.getBrandingColor(
                                'detail-body-list-bg-color', Colors.grey[300])),
                        child: Center(
                            child: Column(children: <Widget>[
                          Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: <Widget>[
                                Text(
                                  'Cost Center',
                                  style: TextStyle(
                                      fontSize: 18.0,
                                      color: EzBranding.getBrandingColor(
                                          'detail-body-list-text-color',
                                          Colors.grey[300])),
                                  textAlign: TextAlign.left,
                                ),
                                Text(
                                  snapshot.data.expenseReportBasics[0]
                                      .costCenterName,
                                  style: TextStyle(
                                      fontSize: 18.0,
                                      color: EzBranding.getBrandingColor(
                                          'detail-body-list-text-color',
                                          Colors.grey[300])),
                                  textAlign: TextAlign.right,
                                )
                              ])
                        ]))),
                    SizedBox(height: 1.0),
                    Container(
                        width: MediaQuery.of(context).size.width,
                        padding: EdgeInsets.all(15.0),
                        margin: EdgeInsets.all(5),
                        decoration: BoxDecoration(
                            border: Border.all(
                                color: EzBranding.getBrandingColor(
                                    'detail-body-list-bg-color',
                                    Colors.grey[300])),
                            borderRadius: BorderRadius.all(Radius.circular(20)),
                            color: EzBranding.getBrandingColor(
                                'detail-body-list-bg-color', Colors.grey[300])),
                        child: Center(
                            child: Column(children: <Widget>[
                          Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: <Widget>[
                                Text(
                                  '# Milage Transactions',
                                  style: TextStyle(
                                      fontSize: 18.0,
                                      color: EzBranding.getBrandingColor(
                                          'detail-body-list-text-color',
                                          Colors.grey[300])),
                                  textAlign: TextAlign.left,
                                ),
                                Text(
                                  snapshot
                                      .data.expenseReportBasics[0].mileagetotal
                                      .toString(),
                                  style: TextStyle(
                                      fontSize: 18.0,
                                      color: EzBranding.getBrandingColor(
                                          'detail-body-list-text-color',
                                          Colors.grey[300])),
                                  textAlign: TextAlign.right,
                                )
                              ])
                        ]))),
                    SizedBox(height: 1.0),
                    Container(
                        width: MediaQuery.of(context).size.width,
                        padding: EdgeInsets.all(15.0),
                        margin: EdgeInsets.all(5),
                        decoration: BoxDecoration(
                            border: Border.all(
                                color: EzBranding.getBrandingColor(
                                    'detail-body-list-bg-color',
                                    Colors.grey[300])),
                            borderRadius: BorderRadius.all(Radius.circular(20)),
                            color: EzBranding.getBrandingColor(
                                'detail-body-list-bg-color', Colors.grey[300])),
                        child: Center(
                            child: Column(children: <Widget>[
                          Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: <Widget>[
                                Text(
                                  '# Out of Pocket Transaction',
                                  style: TextStyle(
                                      fontSize: 18.0,
                                      color: EzBranding.getBrandingColor(
                                          'detail-body-list-text-color',
                                          Colors.grey[300])),
                                  textAlign: TextAlign.left,
                                ),
                                Text(
                                  snapshot.data.expenseReportBasics[0].ooptotal
                                      .toString(),
                                  style: TextStyle(
                                      fontSize: 18.0,
                                      color: EzBranding.getBrandingColor(
                                          'detail-body-list-text-color',
                                          Colors.grey[300])),
                                  textAlign: TextAlign.right,
                                )
                              ])
                        ]))),
                    SizedBox(height: 1.0),
                    Container(
                        width: MediaQuery.of(context).size.width,
                        padding: EdgeInsets.all(15.0),
                        margin: EdgeInsets.all(5),
                        decoration: BoxDecoration(
                            border: Border.all(
                                color: EzBranding.getBrandingColor(
                                    'detail-body-list-bg-color',
                                    Colors.grey[300])),
                            borderRadius: BorderRadius.all(Radius.circular(20)),
                            color: EzBranding.getBrandingColor(
                                'detail-body-list-bg-color', Colors.grey[300])),
                        child: Center(
                            child: Column(children: <Widget>[
                          Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: <Widget>[
                                Text(
                                  '# of Receipts',
                                  style: TextStyle(
                                      fontSize: 18.0,
                                      color: EzBranding.getBrandingColor(
                                          'detail-body-list-text-color',
                                          Colors.grey[300])),
                                  textAlign: TextAlign.left,
                                ),
                                Text(
                                  snapshot
                                      .data.expenseReportBasics[0].reciepttotal
                                      .toString(),
                                  style: TextStyle(
                                      fontSize: 18.0,
                                      color: EzBranding.getBrandingColor(
                                          'detail-body-list-text-color',
                                          Colors.grey[300])),
                                  textAlign: TextAlign.right,
                                )
                              ])
                        ]))),
                    SizedBox(height: 1.0),
                    Container(
                        width: MediaQuery.of(context).size.width,
                        padding: EdgeInsets.all(15.0),
                        margin: EdgeInsets.all(5),
                        decoration: BoxDecoration(
                            border: Border.all(
                                color: EzBranding.getBrandingColor(
                                    'detail-body-list-bg-color',
                                    Colors.grey[300])),
                            borderRadius: BorderRadius.all(Radius.circular(20)),
                            color: EzBranding.getBrandingColor(
                                'detail-body-list-bg-color', Colors.grey[300])),
                        child: Column(children: <Widget>[
                          Column(
                              crossAxisAlignment: CrossAxisAlignment.stretch,
                              children: <Widget>[
                                Text(
                                  'Reviewer Notes: ',
                                  style: TextStyle(
                                      fontSize: 18.0,
                                      color: EzBranding.getBrandingColor(
                                          'detail-body-list-text-color',
                                          Colors.grey[300])),
                                  textAlign: TextAlign.left,
                                ),
                                SizedBox(height: 3.0),
                                Text(
                                  snapshot.data.expenseReportBasics[0]
                                              .reviewNotes ==
                                          null
                                      ? ''
                                      : snapshot.data.expenseReportBasics[0]
                                          .reviewNotes,
                                  style: TextStyle(
                                      fontSize: 18.0,
                                      color: EzBranding.getBrandingColor(
                                          'detail-body-list-text-color',
                                          Colors.grey[300])),
                                  textAlign: TextAlign.left,
                                )
                              ])
                        ])),
                    SizedBox(height: 1.0),
                    Container(
                        width: MediaQuery.of(context).size.width,
                        padding: EdgeInsets.all(15.0),
                        margin: EdgeInsets.all(5),
                        decoration: BoxDecoration(
                            border: Border.all(
                                color: EzBranding.getBrandingColor(
                                    'detail-body-list-bg-color',
                                    Colors.grey[300])),
                            borderRadius: BorderRadius.all(Radius.circular(20)),
                            color: EzBranding.getBrandingColor(
                                'detail-body-list-bg-color', Colors.grey[300])),
                        child: Column(children: <Widget>[
                          Column(
                              crossAxisAlignment: CrossAxisAlignment.stretch,
                              children: <Widget>[
                                Text(
                                  'Cardholder Notes: ',
                                  style: TextStyle(
                                      fontSize: 18.0,
                                      color: EzBranding.getBrandingColor(
                                          'detail-body-list-text-color',
                                          Colors.grey[300])),
                                  textAlign: TextAlign.left,
                                ),
                                SizedBox(height: 3.0),
                                Text(
                                  snapshot.data.expenseReportBasics[0].notes,
                                  style: TextStyle(
                                      fontSize: 18.0,
                                      color: EzBranding.getBrandingColor(
                                          'detail-body-list-text-color',
                                          Colors.grey[300])),
                                  textAlign: TextAlign.left,
                                )
                              ])
                        ])),
                    SizedBox(height: 15.0),
                    Text(
                      '  Transactions',
                      style: TextStyle(fontSize: 25.0),
                    ),
                    Container(
                      //decoration: BoxDecoration(color: Color.fromRGBO(58, 66, 86, 1.0)),
                      child: ListView.builder(
                        scrollDirection: Axis.vertical,
                        shrinkWrap: true,
                        itemCount: snapshot.data.expenseReportItems.length,
                        itemBuilder: (BuildContext context, int index) {
                          return makeTranCard(
                              snapshot.data.expenseReportItems[index]);
                        },
                      ),
                    ),
                    bottomContent
                  ],
                );
              } else {
                return Center(
                  child: CircularProgressIndicator(),
                );
              }
            }));
  }
}
