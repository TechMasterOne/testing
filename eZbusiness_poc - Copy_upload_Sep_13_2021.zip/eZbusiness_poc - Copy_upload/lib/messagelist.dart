import 'package:flutter/material.dart';
import 'package:flutter_app_sample/Model/MessageModel.dart';
import 'package:flutter_app_sample/Service/eZSession.dart';
import 'package:requests/requests.dart';
import 'Service/eZBranding.dart';
//void main() => runApp(new MyApp());

class MessageListPage extends StatelessWidget {
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    /*
    return new MaterialApp(
      title: 'Flutter Demo',
      theme: new ThemeData(
          primaryColor: Color.fromRGBO(58, 66, 86, 1.0), fontFamily: 'Raleway'),
      home: new ListPage(title: 'messages'),
      // home: DetailPage(),
    );
    */

    return Scaffold(
        appBar: AppBar(
          iconTheme: IconThemeData(
              color: EzBranding.getBrandingColor(
                  'app-bar-font-color', Colors.white)),
          elevation: 2.0,
          backgroundColor:
              EzBranding.getBrandingColor('app-bar-bg-color', Colors.pink[900]),
          title: Text('Messages',
              style: TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.w700,
                  fontSize: 25.0)),
          actions: <Widget>[
            Container(
              margin: EdgeInsets.only(right: 8.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: <Widget>[
                  Text(EzSession.getUserName(),
                      style: TextStyle(
                          color: Colors.blue,
                          fontWeight: FontWeight.w700,
                          fontSize: 14.0)),
                  Icon(Icons.arrow_drop_down,
                      color: EzBranding.getBrandingColor(
                          'app-bar-font-color', Colors.white))
                ],
              ),
            )
          ],
        ),
        body: ListPage(title: 'Messages'));
  }
}

class ListPage extends StatefulWidget {
  ListPage({Key key, this.title}) : super(key: key);

  final String title;

  @override
  _ListPageState createState() => _ListPageState();
}

class _ListPageState extends State<ListPage> {
  Future<MessageModel> messages;

  @override
  void initState() {
    messages = getMessages();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    ListTile makeListTile(AdminQueueMsgs message) => ListTile(
          contentPadding:
              EdgeInsets.symmetric(horizontal: 10.0, vertical: 10.0),
          leading: Container(
            padding: EdgeInsets.only(right: 12.0),
            decoration: new BoxDecoration(
                border: new Border(
                    right: new BorderSide(
                        width: 1.0,
                        color: EzBranding.getBrandingColor(
                            'list-partition-color', Colors.white24)))),
            child: Icon(Icons.email,
                color: EzBranding.getBrandingColor(
                    'list-text-color', Colors.white)),
          ),
          title: Text(
            message.requestType,
            style: TextStyle(
                color: EzBranding.getBrandingColor(
                    'list-text-color', Colors.white),
                fontWeight: FontWeight.bold),
          ),
          // subtitle: Text("Intermediate", style: TextStyle(color: Colors.white)),

          subtitle: Row(
            children: <Widget>[
              Expanded(
                  flex: 1,
                  child: Container(
                      // tag: 'hero',
                      child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Text(message.requestdate,
                          style: TextStyle(
                              color: EzBranding.getBrandingColor(
                                  'list-text-color', Colors.white))),
                      Text(message.userName,
                          style: TextStyle(
                              color: EzBranding.getBrandingColor(
                                  'list-text-color', Colors.white))),
                    ],
                  ))),
            ],
          ),
          trailing: Icon(Icons.keyboard_arrow_right,
              color:
                  EzBranding.getBrandingColor('list-text-color', Colors.white),
              size: 30.0),
          onTap: () {},
        );

    Card makeCard(AdminQueueMsgs message) => Card(
          elevation: 8.0,
          margin: new EdgeInsets.symmetric(horizontal: 10.0, vertical: 6.0),
          child: Container(
            decoration: BoxDecoration(
                color: EzBranding.getBrandingColor(
                    'list-bg-color', Colors.grey[600]),
                border: Border.all(
                    color: EzBranding.getBrandingColor(
                        'list-bg-color', Colors.grey[600])),
                borderRadius: BorderRadius.all(Radius.circular(5))),
            child: makeListTile(message),
          ),
        );

    return FutureBuilder<MessageModel>(
        future: messages,
        builder: (context, snapshot) {
          if (snapshot.hasData) {
            return Container(
              //decoration: BoxDecoration(color: Color.fromRGBO(58, 66, 86, 1.0)),
              child: ListView.builder(
                scrollDirection: Axis.vertical,
                shrinkWrap: true,
                itemCount: snapshot.data.adminQueueMsgs.length,
                itemBuilder: (BuildContext context, int index) {
                  return makeCard(snapshot.data.adminQueueMsgs[index]);
                },
              ),
            );
          } else {
            return Center(
              child: CircularProgressIndicator(),
            );
          }
        });
  }
}

Future<MessageModel> getMessages() async {
  var req = await Requests.post(
      'https://ezbusinessmanagementuat.fisglobal.com/api/CustomerService/GetAdminQueueMsgs',
      body: {
        'accountNumber': '',
        'isSearch': false,
        'queueName': '',
        'status': 'All',
        'sysAssocCorpLevelList': null,
        'pageNumber': 1,
        'pageSize': 30,
        'orderBy': null,
        'orderByDirection': 1
      },
      bodyEncoding: RequestBodyEncoding.JSON,
      timeoutSeconds: 60);

  req.raiseForStatus();
  return MessageModel.fromJson(req.json());
}
