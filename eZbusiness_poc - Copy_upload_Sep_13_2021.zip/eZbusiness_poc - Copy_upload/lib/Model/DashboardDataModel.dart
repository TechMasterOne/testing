class DashboardDataModel {
  int id;
  String createdDate;
  List<String> mergingProperies;
  String continuationParameters;
  String dataJson;

  DashboardDataModel(
      {this.id,
      this.createdDate,
      this.mergingProperies,
      this.continuationParameters,
      this.dataJson});

  DashboardDataModel.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    createdDate = json['createdDate'];
    mergingProperies = json['mergingProperies'].cast<String>();
    continuationParameters = json['continuationParameters'];
    dataJson = json['dataJson'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['createdDate'] = this.createdDate;
    data['mergingProperies'] = this.mergingProperies;
    data['continuationParameters'] = this.continuationParameters;
    data['dataJson'] = this.dataJson;
    return data;
  }
}
