class MessageModel {
  List<AdminQueueMsgs> adminQueueMsgs;
  dynamic errmsgs;

  MessageModel({this.adminQueueMsgs, this.errmsgs});

  MessageModel.fromJson(Map<String, dynamic> json) {
    if (json['adminQueueMsgs'] != null) {
      adminQueueMsgs = new List<AdminQueueMsgs>();
      json['adminQueueMsgs'].forEach((v) {
        adminQueueMsgs.add(new AdminQueueMsgs.fromJson(v));
      });
    }
    errmsgs = json['errmsgs'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    if (this.adminQueueMsgs != null) {
      data['adminQueueMsgs'] =
          this.adminQueueMsgs.map((v) => v.toJson()).toList();
    }
    data['errmsgs'] = this.errmsgs;
    return data;
  }
}

class AdminQueueMsgs {
  int messageID;
  String sys;
  String assn;
  String corp;
  String inst;
  String companyID;
  String companyName;
  String cardNumber;
  String name;
  String userName;
  String requestType;
  String requestdate;
  bool highPriority;
  String messageSubject;
  bool isFailedRequest;
  bool allowReplies;
  bool disablereply;
  String fromtype;
  int company;
  int messageRecipientID;
  String status;
  int totalNoRecords;
  bool isAutoApprovalRequired;

  AdminQueueMsgs(
      {this.messageID,
      this.sys,
      this.assn,
      this.corp,
      this.inst,
      this.companyID,
      this.companyName,
      this.cardNumber,
      this.name,
      this.userName,
      this.requestType,
      this.requestdate,
      this.highPriority,
      this.messageSubject,
      this.isFailedRequest,
      this.allowReplies,
      this.disablereply,
      this.fromtype,
      this.company,
      this.messageRecipientID,
      this.status,
      this.totalNoRecords,
      this.isAutoApprovalRequired});

  AdminQueueMsgs.fromJson(Map<String, dynamic> json) {
    messageID = json['messageID'];
    sys = json['sys'];
    assn = json['assn'];
    corp = json['corp'];
    inst = json['inst'];
    companyID = json['companyID'];
    companyName = json['companyName'];
    cardNumber = json['cardNumber'];
    name = json['name'];
    userName = json['userName'];
    requestType = json['requestType'];
    requestdate = json['requestdate'];
    highPriority = json['highPriority'];
    messageSubject = json['messageSubject'];
    isFailedRequest = json['isFailedRequest'];
    allowReplies = json['allowReplies'];
    disablereply = json['disablereply'];
    fromtype = json['fromtype'];
    company = json['company'];
    messageRecipientID = json['messageRecipientID'];
    status = json['status'];
    totalNoRecords = json['totalNoRecords'];
    isAutoApprovalRequired = json['isAutoApprovalRequired'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['messageID'] = this.messageID;
    data['sys'] = this.sys;
    data['assn'] = this.assn;
    data['corp'] = this.corp;
    data['inst'] = this.inst;
    data['companyID'] = this.companyID;
    data['companyName'] = this.companyName;
    data['cardNumber'] = this.cardNumber;
    data['name'] = this.name;
    data['userName'] = this.userName;
    data['requestType'] = this.requestType;
    data['requestdate'] = this.requestdate;
    data['highPriority'] = this.highPriority;
    data['messageSubject'] = this.messageSubject;
    data['isFailedRequest'] = this.isFailedRequest;
    data['allowReplies'] = this.allowReplies;
    data['disablereply'] = this.disablereply;
    data['fromtype'] = this.fromtype;
    data['company'] = this.company;
    data['messageRecipientID'] = this.messageRecipientID;
    data['status'] = this.status;
    data['totalNoRecords'] = this.totalNoRecords;
    data['isAutoApprovalRequired'] = this.isAutoApprovalRequired;
    return data;
  }
}
