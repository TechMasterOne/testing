class CardholderCountModel {
  int totalRecord;

  CardholderCountModel({this.totalRecord});

  CardholderCountModel.fromJson(Map<String, dynamic> json) {
    totalRecord = json['totalRecord'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['totalRecord'] = this.totalRecord;
    return data;
  }
}

class CompanyCountModel {
  int totalRecord;

  CompanyCountModel({this.totalRecord});

  CompanyCountModel.fromJson(Map<String, dynamic> json) {
    totalRecord = json['totalRecord'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['totalRecord'] = this.totalRecord;
    return data;
  }
}
