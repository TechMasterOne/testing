class ExpanseListModel {
  int id;
  String subject;
  int submitByUserID;
  String submitUserName;
  int reviewUserID;
  String reviewUserName;
  String submitDate;
  String lastStatusChangeDate;
  String status;
  double amount;
  String hasManualTrans;
  String hasCategoryExceptions;
  int costCenterID;
  String costCenterName;
  bool isCostCenterActive;
  String hasCostCenterCategoryExceptions;
  double outOfPocketTotal;
  double mileageTotal;
  double personalTotal;
  String hasUnAuthTrans;
  String hasCredits;
  String hasSuppressedTrans;
  String cardHolderName;
  String hasImage;
  int accountid;
  int totalcount;

  ExpanseListModel(
      {this.id,
      this.subject,
      this.submitByUserID,
      this.submitUserName,
      this.reviewUserID,
      this.reviewUserName,
      this.submitDate,
      this.lastStatusChangeDate,
      this.status,
      this.amount,
      this.hasManualTrans,
      this.hasCategoryExceptions,
      this.costCenterID,
      this.costCenterName,
      this.isCostCenterActive,
      this.hasCostCenterCategoryExceptions,
      this.outOfPocketTotal,
      this.mileageTotal,
      this.personalTotal,
      this.hasUnAuthTrans,
      this.hasCredits,
      this.hasSuppressedTrans,
      this.cardHolderName,
      this.hasImage,
      this.accountid,
      this.totalcount});

  ExpanseListModel.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    subject = json['subject'];
    submitByUserID = json['submitByUserID'];
    submitUserName = json['submitUserName'];
    reviewUserID = json['reviewUserID'];
    reviewUserName = json['reviewUserName'];
    submitDate = json['submitDate'];
    lastStatusChangeDate = json['lastStatusChangeDate'];
    status = json['status'];
    amount = json['amount'];
    hasManualTrans = json['hasManualTrans'];
    hasCategoryExceptions = json['hasCategoryExceptions'];
    costCenterID = json['costCenterID'];
    costCenterName = json['costCenterName'];
    isCostCenterActive = json['isCostCenterActive'];
    hasCostCenterCategoryExceptions = json['hasCostCenterCategoryExceptions'];
    outOfPocketTotal = json['outOfPocketTotal'];
    mileageTotal = json['mileageTotal'];
    personalTotal = json['personalTotal'];
    hasUnAuthTrans = json['hasUnAuthTrans'];
    hasCredits = json['hasCredits'];
    hasSuppressedTrans = json['hasSuppressedTrans'];
    cardHolderName = json['cardHolderName'];
    hasImage = json['hasImage'];
    accountid = json['accountid'];
    totalcount = json['totalcount'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['subject'] = this.subject;
    data['submitByUserID'] = this.submitByUserID;
    data['submitUserName'] = this.submitUserName;
    data['reviewUserID'] = this.reviewUserID;
    data['reviewUserName'] = this.reviewUserName;
    data['submitDate'] = this.submitDate;
    data['lastStatusChangeDate'] = this.lastStatusChangeDate;
    data['status'] = this.status;
    data['amount'] = this.amount;
    data['hasManualTrans'] = this.hasManualTrans;
    data['hasCategoryExceptions'] = this.hasCategoryExceptions;
    data['costCenterID'] = this.costCenterID;
    data['costCenterName'] = this.costCenterName;
    data['isCostCenterActive'] = this.isCostCenterActive;
    data['hasCostCenterCategoryExceptions'] =
        this.hasCostCenterCategoryExceptions;
    data['outOfPocketTotal'] = this.outOfPocketTotal;
    data['mileageTotal'] = this.mileageTotal;
    data['personalTotal'] = this.personalTotal;
    data['hasUnAuthTrans'] = this.hasUnAuthTrans;
    data['hasCredits'] = this.hasCredits;
    data['hasSuppressedTrans'] = this.hasSuppressedTrans;
    data['cardHolderName'] = this.cardHolderName;
    data['hasImage'] = this.hasImage;
    data['accountid'] = this.accountid;
    data['totalcount'] = this.totalcount;
    return data;
  }
}
