class ImportantInfoModel {
  String ignoreFlag;
  String expirationFlag;
  String isReadFlag;
  int id;
  bool readFlag;
  bool archiveFlag;
  bool deleteFlag;
  String messageSubject;
  int fromID;
  bool senderArchived;
  bool senderDeleted;
  String messageContent;
  String salutation;
  String firstName;
  String middleName;
  String lastName;
  String suffix;
  String sendDate;
  bool forceView;
  String expirationDate;
  String displayName;
  int disablereply;
  int onlineRequestTypeId;
  bool highPriority;
  String startDate;
  String commercialAccountID;
  bool allowReplies;
  String status;
  int approverExist;
  String approvalID;
  int recpId;
  int messageRecipientId;
  int totalRows;
  int disabledelete;
  String toType;
  bool acceptHide;
  bool msgReadFlag;

  ImportantInfoModel(
      {this.ignoreFlag,
      this.expirationFlag,
      this.isReadFlag,
      this.id,
      this.readFlag,
      this.archiveFlag,
      this.deleteFlag,
      this.messageSubject,
      this.fromID,
      this.senderArchived,
      this.senderDeleted,
      this.messageContent,
      this.salutation,
      this.firstName,
      this.middleName,
      this.lastName,
      this.suffix,
      this.sendDate,
      this.forceView,
      this.expirationDate,
      this.displayName,
      this.disablereply,
      this.onlineRequestTypeId,
      this.highPriority,
      this.startDate,
      this.commercialAccountID,
      this.allowReplies,
      this.status,
      this.approverExist,
      this.approvalID,
      this.recpId,
      this.messageRecipientId,
      this.totalRows,
      this.disabledelete,
      this.toType,
      this.acceptHide,
      this.msgReadFlag});

  ImportantInfoModel.fromJson(Map<String, dynamic> json) {
    ignoreFlag = json['ignoreFlag'];
    expirationFlag = json['expirationFlag'];
    isReadFlag = json['isReadFlag'];
    id = json['id'];
    readFlag = json['readFlag'];
    archiveFlag = json['archiveFlag'];
    deleteFlag = json['deleteFlag'];
    messageSubject = json['messageSubject'];
    fromID = json['fromID'];
    senderArchived = json['senderArchived'];
    senderDeleted = json['senderDeleted'];
    messageContent = json['messageContent'];
    salutation = json['salutation'];
    firstName = json['firstName'];
    middleName = json['middleName'];
    lastName = json['lastName'];
    suffix = json['suffix'];
    sendDate = json['sendDate'];
    forceView = json['forceView'];
    expirationDate = json['expirationDate'];
    displayName = json['displayName'];
    disablereply = json['disablereply'];
    onlineRequestTypeId = json['onlineRequestTypeId'];
    highPriority = json['highPriority'];
    startDate = json['startDate'];
    commercialAccountID = json['commercialAccountID'];
    allowReplies = json['allowReplies'];
    status = json['status'];
    approverExist = json['approverExist'];
    approvalID = json['approvalID'];
    recpId = json['recpId'];
    messageRecipientId = json['messageRecipientId'];
    totalRows = json['totalRows'];
    disabledelete = json['disabledelete'];
    toType = json['toType'];
    acceptHide = json['acceptHide'];
    msgReadFlag = json['msgReadFlag'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['ignoreFlag'] = this.ignoreFlag;
    data['expirationFlag'] = this.expirationFlag;
    data['isReadFlag'] = this.isReadFlag;
    data['id'] = this.id;
    data['readFlag'] = this.readFlag;
    data['archiveFlag'] = this.archiveFlag;
    data['deleteFlag'] = this.deleteFlag;
    data['messageSubject'] = this.messageSubject;
    data['fromID'] = this.fromID;
    data['senderArchived'] = this.senderArchived;
    data['senderDeleted'] = this.senderDeleted;
    data['messageContent'] = this.messageContent;
    data['salutation'] = this.salutation;
    data['firstName'] = this.firstName;
    data['middleName'] = this.middleName;
    data['lastName'] = this.lastName;
    data['suffix'] = this.suffix;
    data['sendDate'] = this.sendDate;
    data['forceView'] = this.forceView;
    data['expirationDate'] = this.expirationDate;
    data['displayName'] = this.displayName;
    data['disablereply'] = this.disablereply;
    data['onlineRequestTypeId'] = this.onlineRequestTypeId;
    data['highPriority'] = this.highPriority;
    data['startDate'] = this.startDate;
    data['commercialAccountID'] = this.commercialAccountID;
    data['allowReplies'] = this.allowReplies;
    data['status'] = this.status;
    data['approverExist'] = this.approverExist;
    data['approvalID'] = this.approvalID;
    data['recpId'] = this.recpId;
    data['messageRecipientId'] = this.messageRecipientId;
    data['totalRows'] = this.totalRows;
    data['disabledelete'] = this.disabledelete;
    data['toType'] = this.toType;
    data['acceptHide'] = this.acceptHide;
    data['msgReadFlag'] = this.msgReadFlag;
    return data;
  }
}
