import 'CardholderModel.dart';

class CardholderDetailModel {
  CardholderDetail cardholderDetail;
  CardholderModel cardholderModel;
}

class CardholderGraph {
  final int id;
  final String type;
  final double amount;

  CardholderGraph(this.id, this.type, this.amount);
}

class CardholderDetail {
  int id;
  int accountId;
  String name;
  String lastName;
  String firstName;
  String cardHolderName;
  String status;
  String accountLast4;
  String billingAccountLast4;
  String blockReclass;
  bool adminAccountLock;
  String procType;
  double accountBalance;
  double availableCredit;
  double availableCash;
  double creditLimit;
  double cashLimit;
  double minimumPaymentDue;
  double lastPaymentAmount;
  double cashBalance;
  double pastDueAmount;
  double lastStatementAmount;
  double pendingBalance;
  String cardholderSince;
  String paymentDueDate;
  String lastPaymentDate;
  String expirationDate;
  String lastStatementDate;
  String lastActivityDate;
  String statementDeliveryOption;
  bool hasChipCard;
  bool isCentrallyBilled;
  bool isCommercialCard;
  bool isOverLimitOptIn;
  bool isUDAPLawApplies;
  bool temporaryAuthBlock;
  bool delayedBlockFlag;
  double ctDiverted;
  double ctDivertedCash;
  String currentCycleDate;
  String closeDate;
  String openDate;
  String previousExpDate;
  String previousLast4;
  String businessCardAccountTypeIndicator;
  int userHierarchy;
  String lastUpdated;
  String lastUpdatedDate;
  bool isBlockPayments;
  bool allowOnlinePayments;
  bool hasCardForActivation;
  String dateOfBirth;
  String maidenName;
  String userName;
  bool denyAccess;
  int failedLoginAttempts;
  int failedEnrollmentAttempts;
  bool isEnrolledBySSO;
  String ssoVersion;
  int userId;
  bool isInactivityFlag;
  bool isMFAEnrolled;
  bool isMFALocked;
  double currentTempCreditLimit;
  String ssnLast4;
  double adjustedTempCreditLimit;
  String accountType;
  bool isUserGeminiLock;
  bool isUserGeminiEnrolled;
  String userSecurityAccountStatusLastAccDate;
  String userEnrollmentStatusLastAccDate;
  String passwordFailureLastAccDate;
  String userAccountStatusLastAccAdte;
  String userStatusLastAccDate;
  bool tempBlock;
  String milIndicator;
  String accountActivationStatus;
  bool isPaymentBlocked;
  String userPaymentLastActivityDate;
  String blockReclassDisplayName;

  CardholderDetail(
      {this.id,
      this.accountId,
      this.name,
      this.lastName,
      this.firstName,
      this.cardHolderName,
      this.status,
      this.accountLast4,
      this.billingAccountLast4,
      this.blockReclass,
      this.adminAccountLock,
      this.procType,
      this.accountBalance,
      this.availableCredit,
      this.availableCash,
      this.creditLimit,
      this.cashLimit,
      this.minimumPaymentDue,
      this.lastPaymentAmount,
      this.cashBalance,
      this.pastDueAmount,
      this.lastStatementAmount,
      this.pendingBalance,
      this.cardholderSince,
      this.paymentDueDate,
      this.lastPaymentDate,
      this.expirationDate,
      this.lastStatementDate,
      this.lastActivityDate,
      this.statementDeliveryOption,
      this.hasChipCard,
      this.isCentrallyBilled,
      this.isCommercialCard,
      this.isOverLimitOptIn,
      this.isUDAPLawApplies,
      this.temporaryAuthBlock,
      this.delayedBlockFlag,
      this.ctDiverted,
      this.ctDivertedCash,
      this.currentCycleDate,
      this.closeDate,
      this.openDate,
      this.previousExpDate,
      this.previousLast4,
      this.businessCardAccountTypeIndicator,
      this.userHierarchy,
      this.lastUpdated,
      this.lastUpdatedDate,
      this.isBlockPayments,
      this.allowOnlinePayments,
      this.hasCardForActivation,
      this.dateOfBirth,
      this.maidenName,
      this.userName,
      this.denyAccess,
      this.failedLoginAttempts,
      this.failedEnrollmentAttempts,
      this.isEnrolledBySSO,
      this.ssoVersion,
      this.userId,
      this.isInactivityFlag,
      this.isMFAEnrolled,
      this.isMFALocked,
      this.currentTempCreditLimit,
      this.ssnLast4,
      this.adjustedTempCreditLimit,
      this.accountType,
      this.isUserGeminiLock,
      this.isUserGeminiEnrolled,
      this.userSecurityAccountStatusLastAccDate,
      this.userEnrollmentStatusLastAccDate,
      this.passwordFailureLastAccDate,
      this.userAccountStatusLastAccAdte,
      this.userStatusLastAccDate,
      this.tempBlock,
      this.milIndicator,
      this.accountActivationStatus,
      this.isPaymentBlocked,
      this.userPaymentLastActivityDate,
      this.blockReclassDisplayName});

  CardholderDetail.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    accountId = json['accountId'];
    name = json['name'];
    lastName = json['lastName'];
    firstName = json['firstName'];
    cardHolderName = json['cardHolderName'];
    status = json['status'];
    accountLast4 = json['accountLast4'];
    billingAccountLast4 = json['billingAccountLast4'];
    blockReclass = json['blockReclass'];
    adminAccountLock = json['adminAccountLock'];
    procType = json['procType'];
    accountBalance = json['accountBalance'];
    availableCredit = json['availableCredit'];
    availableCash = json['availableCash'];
    creditLimit = json['creditLimit'];
    cashLimit = json['cashLimit'];
    minimumPaymentDue = json['minimumPaymentDue'];
    lastPaymentAmount = json['lastPaymentAmount'];
    cashBalance = json['cashBalance'];
    pastDueAmount = json['pastDueAmount'];
    lastStatementAmount = json['lastStatementAmount'];
    pendingBalance = json['pendingBalance'];
    cardholderSince = json['cardholderSince'];
    paymentDueDate = json['paymentDueDate'];
    lastPaymentDate = json['lastPaymentDate'];
    expirationDate = json['expirationDate'];
    lastStatementDate = json['lastStatementDate'];
    lastActivityDate = json['lastActivityDate'];
    statementDeliveryOption = json['statementDeliveryOption'];
    hasChipCard = json['hasChipCard'];
    isCentrallyBilled = json['isCentrallyBilled'];
    isCommercialCard = json['isCommercialCard'];
    isOverLimitOptIn = json['isOverLimitOptIn'];
    isUDAPLawApplies = json['isUDAPLawApplies'];
    temporaryAuthBlock = json['temporaryAuthBlock'];
    delayedBlockFlag = json['delayedBlockFlag'];
    ctDiverted = json['ctDiverted'];
    ctDivertedCash = json['ctDivertedCash'];
    currentCycleDate = json['currentCycleDate'];
    closeDate = json['closeDate'];
    openDate = json['openDate'];
    previousExpDate = json['previousExpDate'];
    previousLast4 = json['previousLast4'];
    businessCardAccountTypeIndicator = json['businessCardAccountTypeIndicator'];
    userHierarchy = json['userHierarchy'];
    lastUpdated = json['lastUpdated'];
    lastUpdatedDate = json['lastUpdatedDate'];
    isBlockPayments = json['isBlockPayments'];
    allowOnlinePayments = json['allowOnlinePayments'];
    hasCardForActivation = json['hasCardForActivation'];
    dateOfBirth = json['dateOfBirth'];
    maidenName = json['maidenName'] ?? '';
    userName = json['userName'] ?? '';
    denyAccess = json['denyAccess'];
    failedLoginAttempts = json['failedLoginAttempts'];
    failedEnrollmentAttempts = json['failedEnrollmentAttempts'];
    isEnrolledBySSO =
        json['isEnrolledBySSO'] == null ? false : json['isEnrolledBySSO'];
    ssoVersion = json['ssoVersion'];
    userId = json['userId'];
    isInactivityFlag = json['isInactivityFlag'];
    isMFAEnrolled =
        json['isMFAEnrolled'] == null ? false : json['isMFAEnrolled'];
    isMFALocked = json['isMFALocked'];
    currentTempCreditLimit = json['currentTempCreditLimit'] == null
        ? 0.0
        : json['currentTempCreditLimit'];
    ssnLast4 = json['ssnLast4'];
    adjustedTempCreditLimit = json['adjustedTempCreditLimit'] == null
        ? 0.0
        : json['adjustedTempCreditLimit'];
    accountType = json['accountType'];
    isUserGeminiLock = json['isUserGeminiLock'];
    isUserGeminiEnrolled = json['isUserGeminiEnrolled'];
    userSecurityAccountStatusLastAccDate =
        json['userSecurityAccountStatusLastAccDate'];
    userEnrollmentStatusLastAccDate = json['userEnrollmentStatusLastAccDate'];
    passwordFailureLastAccDate = json['passwordFailureLastAccDate'];
    userAccountStatusLastAccAdte = json['userAccountStatusLastAccAdte'];
    userStatusLastAccDate = json['userStatusLastAccDate'];
    tempBlock = json['tempBlock'];
    milIndicator = json['milIndicator'];
    accountActivationStatus = json['accountActivationStatus'];
    isPaymentBlocked = json['isPaymentBlocked'] == null ? false : true;
    userPaymentLastActivityDate = json['userPaymentLastActivityDate'];
    blockReclassDisplayName = json['blockReclassDisplayName'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['accountId'] = this.accountId;
    data['name'] = this.name;
    data['lastName'] = this.lastName;
    data['firstName'] = this.firstName;
    data['cardHolderName'] = this.cardHolderName;
    data['status'] = this.status;
    data['accountLast4'] = this.accountLast4;
    data['billingAccountLast4'] = this.billingAccountLast4;
    data['blockReclass'] = this.blockReclass;
    data['adminAccountLock'] = this.adminAccountLock;
    data['procType'] = this.procType;
    data['accountBalance'] = this.accountBalance;
    data['availableCredit'] = this.availableCredit;
    data['availableCash'] = this.availableCash;
    data['creditLimit'] = this.creditLimit;
    data['cashLimit'] = this.cashLimit;
    data['minimumPaymentDue'] = this.minimumPaymentDue;
    data['lastPaymentAmount'] = this.lastPaymentAmount;
    data['cashBalance'] = this.cashBalance;
    data['pastDueAmount'] = this.pastDueAmount;
    data['lastStatementAmount'] = this.lastStatementAmount;
    data['pendingBalance'] = this.pendingBalance;
    data['cardholderSince'] = this.cardholderSince;
    data['paymentDueDate'] = this.paymentDueDate;
    data['lastPaymentDate'] = this.lastPaymentDate;
    data['expirationDate'] = this.expirationDate;
    data['lastStatementDate'] = this.lastStatementDate;
    data['lastActivityDate'] = this.lastActivityDate;
    data['statementDeliveryOption'] = this.statementDeliveryOption;
    data['hasChipCard'] = this.hasChipCard;
    data['isCentrallyBilled'] = this.isCentrallyBilled;
    data['isCommercialCard'] = this.isCommercialCard;
    data['isOverLimitOptIn'] = this.isOverLimitOptIn;
    data['isUDAPLawApplies'] = this.isUDAPLawApplies;
    data['temporaryAuthBlock'] = this.temporaryAuthBlock;
    data['delayedBlockFlag'] = this.delayedBlockFlag;
    data['ctDiverted'] = this.ctDiverted;
    data['ctDivertedCash'] = this.ctDivertedCash;
    data['currentCycleDate'] = this.currentCycleDate;
    data['closeDate'] = this.closeDate;
    data['openDate'] = this.openDate;
    data['previousExpDate'] = this.previousExpDate;
    data['previousLast4'] = this.previousLast4;
    data['businessCardAccountTypeIndicator'] =
        this.businessCardAccountTypeIndicator;
    data['userHierarchy'] = this.userHierarchy;
    data['lastUpdated'] = this.lastUpdated;
    data['lastUpdatedDate'] = this.lastUpdatedDate;
    data['isBlockPayments'] = this.isBlockPayments;
    data['allowOnlinePayments'] = this.allowOnlinePayments;
    data['hasCardForActivation'] = this.hasCardForActivation;
    data['dateOfBirth'] = this.dateOfBirth;
    data['maidenName'] = this.maidenName;
    data['userName'] = this.userName;
    data['denyAccess'] = this.denyAccess;
    data['failedLoginAttempts'] = this.failedLoginAttempts;
    data['failedEnrollmentAttempts'] = this.failedEnrollmentAttempts;
    data['isEnrolledBySSO'] = this.isEnrolledBySSO;
    data['ssoVersion'] = this.ssoVersion;
    data['userId'] = this.userId;
    data['isInactivityFlag'] = this.isInactivityFlag;
    data['isMFAEnrolled'] = this.isMFAEnrolled;
    data['isMFALocked'] = this.isMFALocked;
    data['currentTempCreditLimit'] = this.currentTempCreditLimit;
    data['ssnLast4'] = this.ssnLast4;
    data['adjustedTempCreditLimit'] = this.adjustedTempCreditLimit;
    data['accountType'] = this.accountType;
    data['isUserGeminiLock'] = this.isUserGeminiLock;
    data['isUserGeminiEnrolled'] = this.isUserGeminiEnrolled;
    data['userSecurityAccountStatusLastAccDate'] =
        this.userSecurityAccountStatusLastAccDate;
    data['userEnrollmentStatusLastAccDate'] =
        this.userEnrollmentStatusLastAccDate;
    data['passwordFailureLastAccDate'] = this.passwordFailureLastAccDate;
    data['userAccountStatusLastAccAdte'] = this.userAccountStatusLastAccAdte;
    data['userStatusLastAccDate'] = this.userStatusLastAccDate;
    data['tempBlock'] = this.tempBlock;
    data['milIndicator'] = this.milIndicator;
    data['accountActivationStatus'] = this.accountActivationStatus;
    data['isPaymentBlocked'] = this.isPaymentBlocked;
    data['userPaymentLastActivityDate'] = this.userPaymentLastActivityDate;
    data['blockReclassDisplayName'] = this.blockReclassDisplayName;
    return data;
  }
}
