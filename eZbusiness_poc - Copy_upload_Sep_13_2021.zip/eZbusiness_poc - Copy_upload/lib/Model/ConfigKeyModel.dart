class ConfigKeyModel {
  int id;
  int setId;
  int configKeyId;
  String keyName;
  String keyValue;
  bool allowChildValues;
  bool isOverride;
  int weighting;
  int level;
  int rnWeight;
  int minLevel;
  bool showIt;
  bool showValueAsConsolidated;
  bool isSystem;
  String tagName;
  bool canModify;

  ConfigKeyModel(
      {this.id,
      this.setId,
      this.configKeyId,
      this.keyName,
      this.keyValue,
      this.allowChildValues,
      this.isOverride,
      this.weighting,
      this.level,
      this.rnWeight,
      this.minLevel,
      this.showIt,
      this.showValueAsConsolidated,
      this.isSystem,
      this.tagName,
      this.canModify});

  ConfigKeyModel.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    setId = json['setId'];
    configKeyId = json['configKeyId'];
    keyName = json['keyName'];
    keyValue = json['keyValue'];
    allowChildValues = json['allowChildValues'];
    isOverride = json['isOverride'];
    weighting = json['weighting'];
    level = json['level'];
    rnWeight = json['rnWeight'];
    minLevel = json['minLevel'];
    showIt = json['showIt'];
    showValueAsConsolidated = json['showValueAsConsolidated'];
    isSystem = json['isSystem'];
    tagName = json['tagName'];
    canModify = json['canModify'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['setId'] = this.setId;
    data['configKeyId'] = this.configKeyId;
    data['keyName'] = this.keyName;
    data['keyValue'] = this.keyValue;
    data['allowChildValues'] = this.allowChildValues;
    data['isOverride'] = this.isOverride;
    data['weighting'] = this.weighting;
    data['level'] = this.level;
    data['rnWeight'] = this.rnWeight;
    data['minLevel'] = this.minLevel;
    data['showIt'] = this.showIt;
    data['showValueAsConsolidated'] = this.showValueAsConsolidated;
    data['isSystem'] = this.isSystem;
    data['tagName'] = this.tagName;
    data['canModify'] = this.canModify;
    return data;
  }
}
