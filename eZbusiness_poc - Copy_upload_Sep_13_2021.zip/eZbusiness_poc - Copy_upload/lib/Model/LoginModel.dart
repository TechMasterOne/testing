class LoginModel {
  String ssopacket;
  int id;
  String username;
  String password;
  String token;
  String phoneOTP;
  int state;
  String messages;
  LoginErrorMessages errorMessages;
  String challengeQuestion;
  String challengeAnswer;
  String landingPage;
  String devicePrint;
  int challengeOption;
  String isSecurityAccountNotAvailable;
  String isFeatureNotAvailable;
  String systemCode;
  String isMultiLevelUser;
  String challengeQuestiondata;
  String adminUserPhone;
  String adminEmail;
  bool isrsalock;
  bool isInvalidAnswer;
  bool isFeignUser;
  bool isCurrentPasswordInvalid;
  int phoneId;
  bool isqueyauthdiscont;
  bool isSMS;
  bool isEmail;
  bool isQueyAuthDisCont;
  bool isOOBPhoneChallengeSuccess;
  String approvalData;
  String redirectURL;
  String isCompanyApprover;
  String isCorpApprover;
  List<AdminPhoneByUserIdLists> adminPhoneByUserIdLists;
  bool isForgotPassword;
  String isChangePasswordSuccess;
  String isSecurityAuthenticationFail;
  bool landingPageAccess;

  LoginModel(
      {this.ssopacket,
      this.id,
      this.username,
      this.password,
      this.token,
      this.phoneOTP,
      this.state,
      this.messages,
      this.errorMessages,
      this.challengeQuestion,
      this.challengeAnswer,
      this.landingPage,
      this.devicePrint,
      this.challengeOption,
      this.isSecurityAccountNotAvailable,
      this.isFeatureNotAvailable,
      this.systemCode,
      this.isMultiLevelUser,
      this.challengeQuestiondata,
      this.adminUserPhone,
      this.adminEmail,
      this.isrsalock,
      this.isInvalidAnswer,
      this.isFeignUser,
      this.isCurrentPasswordInvalid,
      this.phoneId,
      this.isqueyauthdiscont,
      this.isSMS,
      this.isEmail,
      this.isQueyAuthDisCont,
      this.isOOBPhoneChallengeSuccess,
      this.approvalData,
      this.redirectURL,
      this.isCompanyApprover,
      this.isCorpApprover,
      this.adminPhoneByUserIdLists,
      this.isForgotPassword,
      this.isChangePasswordSuccess,
      this.isSecurityAuthenticationFail,
      this.landingPageAccess});

  LoginModel.fromJson(Map<String, dynamic> json) {
    ssopacket = json['ssopacket'];
    id = json['id'];
    username = json['username'];
    password = json['password'];
    token = json['token'];
    phoneOTP = json['phoneOTP'];
    state = json['state'];
    messages = json['messages'];
    errorMessages = json['errorMessages'] != null
        ? new LoginErrorMessages.fromJson(json['errorMessages'])
        : null;
    challengeQuestion = json['challengeQuestion'];
    challengeAnswer = json['challengeAnswer'];
    landingPage = json['landingPage'];
    devicePrint = json['devicePrint'];
    challengeOption = json['challengeOption'];
    isSecurityAccountNotAvailable = json['isSecurityAccountNotAvailable'];
    isFeatureNotAvailable = json['isFeatureNotAvailable'];
    systemCode = json['systemCode'];
    isMultiLevelUser = json['isMultiLevelUser'];
    challengeQuestiondata = json['challengeQuestiondata'];
    adminUserPhone = json['adminUserPhone'];
    adminEmail = json['adminEmail'];
    isrsalock = json['isrsalock'];
    isInvalidAnswer = json['isInvalidAnswer'];
    isFeignUser = json['isFeignUser'];
    isCurrentPasswordInvalid = json['isCurrentPasswordInvalid'];
    phoneId = json['phoneId'];
    isqueyauthdiscont = json['isqueyauthdiscont'];
    isSMS = json['isSMS'];
    isEmail = json['isEmail'];
    isQueyAuthDisCont = json['isQueyAuthDisCont'];
    isOOBPhoneChallengeSuccess = json['isOOBPhoneChallengeSuccess'];
    approvalData = json['approvalData'];
    redirectURL = json['redirectURL'];
    isCompanyApprover = json['isCompanyApprover'];
    isCorpApprover = json['isCorpApprover'];
    if (json['adminPhoneByUserIdLists'] != null) {
      adminPhoneByUserIdLists = new List<AdminPhoneByUserIdLists>();
      json['adminPhoneByUserIdLists'].forEach((v) {
        adminPhoneByUserIdLists.add(new AdminPhoneByUserIdLists.fromJson(v));
      });
    }
    isForgotPassword = json['isForgotPassword'];
    isChangePasswordSuccess = json['isChangePasswordSuccess'];
    isSecurityAuthenticationFail = json['isSecurityAuthenticationFail'];
    landingPageAccess = json['landingPageAccess'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['ssopacket'] = this.ssopacket;
    data['id'] = this.id;
    data['username'] = this.username;
    data['password'] = this.password;
    data['token'] = this.token;
    data['phoneOTP'] = this.phoneOTP;
    data['state'] = this.state;
    data['messages'] = this.messages;
    if (this.errorMessages != null) {
      data['errorMessages'] = this.errorMessages.toJson();
    }
    data['challengeQuestion'] = this.challengeQuestion;
    data['challengeAnswer'] = this.challengeAnswer;
    data['landingPage'] = this.landingPage;
    data['devicePrint'] = this.devicePrint;
    data['challengeOption'] = this.challengeOption;
    data['isSecurityAccountNotAvailable'] = this.isSecurityAccountNotAvailable;
    data['isFeatureNotAvailable'] = this.isFeatureNotAvailable;
    data['systemCode'] = this.systemCode;
    data['isMultiLevelUser'] = this.isMultiLevelUser;
    data['challengeQuestiondata'] = this.challengeQuestiondata;
    data['adminUserPhone'] = this.adminUserPhone;
    data['adminEmail'] = this.adminEmail;
    data['isrsalock'] = this.isrsalock;
    data['isInvalidAnswer'] = this.isInvalidAnswer;
    data['isFeignUser'] = this.isFeignUser;
    data['isCurrentPasswordInvalid'] = this.isCurrentPasswordInvalid;
    data['phoneId'] = this.phoneId;
    data['isqueyauthdiscont'] = this.isqueyauthdiscont;
    data['isSMS'] = this.isSMS;
    data['isEmail'] = this.isEmail;
    data['isQueyAuthDisCont'] = this.isQueyAuthDisCont;
    data['isOOBPhoneChallengeSuccess'] = this.isOOBPhoneChallengeSuccess;
    data['approvalData'] = this.approvalData;
    data['redirectURL'] = this.redirectURL;
    data['isCompanyApprover'] = this.isCompanyApprover;
    data['isCorpApprover'] = this.isCorpApprover;
    if (this.adminPhoneByUserIdLists != null) {
      data['adminPhoneByUserIdLists'] =
          this.adminPhoneByUserIdLists.map((v) => v.toJson()).toList();
    }
    data['isForgotPassword'] = this.isForgotPassword;
    data['isChangePasswordSuccess'] = this.isChangePasswordSuccess;
    data['isSecurityAuthenticationFail'] = this.isSecurityAuthenticationFail;
    data['landingPageAccess'] = this.landingPageAccess;
    return data;
  }
}

class LoginErrorMessages {
  String invalidLogin;

  LoginErrorMessages({this.invalidLogin});

  LoginErrorMessages.fromJson(Map<String, dynamic> json) {
    invalidLogin = json['InvalidLogin'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['InvalidLogin'] = this.invalidLogin;
    return data;
  }
}

class AdminPhoneByUserIdLists {
  int id;
  String username;
  String phone;
  String phoneExt;
  String phoneCountryCode;
  String phoneAreaCode;
  String phoneCountryCallingCode;
  String phoneType;
  int userId;

  AdminPhoneByUserIdLists(
      {this.id,
      this.username,
      this.phone,
      this.phoneExt,
      this.phoneCountryCode,
      this.phoneAreaCode,
      this.phoneCountryCallingCode,
      this.phoneType,
      this.userId});

  AdminPhoneByUserIdLists.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    username = json['username'];
    phone = json['phone'];
    phoneExt = json['phoneExt'];
    phoneCountryCode = json['phoneCountryCode'];
    phoneAreaCode = json['phoneAreaCode'];
    phoneCountryCallingCode = json['phoneCountryCallingCode'];
    phoneType = json['phoneType'];
    userId = json['userId'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['username'] = this.username;
    data['phone'] = this.phone;
    data['phoneExt'] = this.phoneExt;
    data['phoneCountryCode'] = this.phoneCountryCode;
    data['phoneAreaCode'] = this.phoneAreaCode;
    data['phoneCountryCallingCode'] = this.phoneCountryCallingCode;
    data['phoneType'] = this.phoneType;
    data['userId'] = this.userId;
    return data;
  }
}
