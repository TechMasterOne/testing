class LoginUserDetailModel {
  String lastSuccessfulLogin;
  String username;
  int levelId;

  LoginUserDetailModel({this.lastSuccessfulLogin, this.username, this.levelId});

  LoginUserDetailModel.fromJson(Map<String, dynamic> json) {
    lastSuccessfulLogin = json['lastSuccessfulLogin'];
    username = json['username'];
    levelId = json['levelId'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['lastSuccessfulLogin'] = this.lastSuccessfulLogin;
    data['username'] = this.username;
    data['levelId'] = this.levelId;
    return data;
  }
}

class UserLevelModel {
  int adminuserid;
  int levelId;
  String code;
  String displayName;

  UserLevelModel({this.adminuserid, this.levelId, this.code, this.displayName});

  UserLevelModel.fromJson(Map<String, dynamic> json) {
    adminuserid = json['adminuserid'];
    levelId = json['levelId'];
    code = json['code'];
    displayName = json['displayName'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['adminuserid'] = this.adminuserid;
    data['levelId'] = this.levelId;
    data['code'] = this.code;
    data['displayName'] = this.displayName;
    return data;
  }
}
