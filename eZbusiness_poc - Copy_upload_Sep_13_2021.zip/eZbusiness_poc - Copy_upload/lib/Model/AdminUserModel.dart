class AdminUserModel {
  int loggedInAdminUserHierarchyRank;
  String loginUserLevel;
  String singleMultiUser;
  int totalRecords;
  String system;
  String association;
  String corporation;
  String institution;
  int adminUserId;
  String username;
  String firstName;
  String lastName;
  String loginStatus;
  String lastLoginDate;
  String lastFailedLoginDate;
  String loginType;
  bool deleteFlag;
  bool denyAccess;
  bool manageFlag;
  String department;
  String postalcode;
  String state;
  String emailAddress;
  String mailCode;
  String ssoUser;
  String userStatus;
  int profileId;
  String profileName;
  bool isMappedToAdmin;
  bool isCompanyAdmin;

  AdminUserModel(
      {this.loggedInAdminUserHierarchyRank,
      this.loginUserLevel,
      this.singleMultiUser,
      this.totalRecords,
      this.system,
      this.association,
      this.corporation,
      this.institution,
      this.adminUserId,
      this.username,
      this.firstName,
      this.lastName,
      this.loginStatus,
      this.lastLoginDate,
      this.lastFailedLoginDate,
      this.loginType,
      this.deleteFlag,
      this.denyAccess,
      this.manageFlag,
      this.department,
      this.postalcode,
      this.state,
      this.emailAddress,
      this.mailCode,
      this.ssoUser,
      this.userStatus,
      this.profileId,
      this.profileName,
      this.isMappedToAdmin,
      this.isCompanyAdmin});

  AdminUserModel.fromJson(Map<String, dynamic> json) {
    loggedInAdminUserHierarchyRank = json['loggedInAdminUserHierarchyRank'];
    loginUserLevel = json['loginUserLevel'];
    singleMultiUser = json['singleMultiUser'];
    totalRecords = json['totalRecords'];
    system = json['system'];
    association = json['association'];
    corporation = json['corporation'];
    institution = json['institution'];
    adminUserId = json['adminUserId'];
    username = json['username'];
    firstName = json['firstName'];
    lastName = json['lastName'];
    loginStatus = json['loginStatus'];
    lastLoginDate = json['lastLoginDate'];
    lastFailedLoginDate = json['lastFailedLoginDate'];
    loginType = json['loginType'];
    deleteFlag = json['deleteFlag'];
    denyAccess = json['denyAccess'];
    manageFlag = json['manageFlag'];
    department = json['department'];
    postalcode = json['postalcode'];
    state = json['state'];
    emailAddress = json['emailAddress'];
    mailCode = json['mailCode'];
    ssoUser = json['ssoUser'];
    userStatus = json['userStatus'];
    profileId = json['profileId'];
    profileName = json['profileName'];
    isMappedToAdmin = json['isMappedToAdmin'];
    isCompanyAdmin = json['isCompanyAdmin'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['loggedInAdminUserHierarchyRank'] =
        this.loggedInAdminUserHierarchyRank;
    data['loginUserLevel'] = this.loginUserLevel;
    data['singleMultiUser'] = this.singleMultiUser;
    data['totalRecords'] = this.totalRecords;
    data['system'] = this.system;
    data['association'] = this.association;
    data['corporation'] = this.corporation;
    data['institution'] = this.institution;
    data['adminUserId'] = this.adminUserId;
    data['username'] = this.username;
    data['firstName'] = this.firstName;
    data['lastName'] = this.lastName;
    data['loginStatus'] = this.loginStatus;
    data['lastLoginDate'] = this.lastLoginDate;
    data['lastFailedLoginDate'] = this.lastFailedLoginDate;
    data['loginType'] = this.loginType;
    data['deleteFlag'] = this.deleteFlag;
    data['denyAccess'] = this.denyAccess;
    data['manageFlag'] = this.manageFlag;
    data['department'] = this.department;
    data['postalcode'] = this.postalcode;
    data['state'] = this.state;
    data['emailAddress'] = this.emailAddress;
    data['mailCode'] = this.mailCode;
    data['ssoUser'] = this.ssoUser;
    data['userStatus'] = this.userStatus;
    data['profileId'] = this.profileId;
    data['profileName'] = this.profileName;
    data['isMappedToAdmin'] = this.isMappedToAdmin;
    data['isCompanyAdmin'] = this.isCompanyAdmin;
    return data;
  }
}
