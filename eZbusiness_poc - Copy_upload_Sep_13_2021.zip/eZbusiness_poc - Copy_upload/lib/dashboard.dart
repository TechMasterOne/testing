import 'package:flutter/material.dart';
import 'package:flutter_app_sample/Model/AdminUserModel.dart';
import 'package:flutter_app_sample/Model/ExpanseListModel.dart';
import 'package:flutter_app_sample/Model/ImportantInfoModel.dart';
import 'package:flutter_app_sample/cardholderlist.dart';
import 'package:flutter_app_sample/adminlist.dart';
import 'package:flutter_app_sample/impinfolist.dart';
import 'package:flutter_app_sample/messagelist.dart';
import 'package:flutter_sparkline/flutter_sparkline.dart';
import 'package:flutter_staggered_grid_view/flutter_staggered_grid_view.dart';
import 'package:requests/requests.dart';
import 'Model/CountModel.dart';
import 'Model/DashboardModel.dart';
import 'Service/eZBranding.dart';
import 'Service/eZSession.dart';
import 'explist.dart';

class DashboardPage extends StatefulWidget {
  @override
  _DashboardPageState createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage> {
  final List<List<double>> charts = [
    [
      4.0,
      3.3,
      2.7,
      1.6,
      0.55,
      0.8,
      1.2,
      1.3,
      1.35,
      0.9,
      1.5,
      1.7,
      1.8,
      1.7,
      1.2,
      0.8,
      1.9,
      2.0,
      2.2,
      1.9,
      2.2,
      2.1,
      2.0,
      2.3,
      2.4,
      2.45,
      2.6,
      3.6,
      2.6,
      2.7,
      2.9,
      2.8,
      3.4
    ],
    [
      4.0,
      3.3,
      2.7,
      1.6,
      0.55,
      0.8,
      1.2,
      1.3,
      1.35,
      0.9,
      1.5,
      1.7,
      1.8,
      1.7,
      1.2,
      0.8,
      1.9,
      2.0,
      2.2,
      1.9,
      2.2,
      2.1,
      2.0,
      2.3,
      2.4,
      2.45,
      2.6,
      3.6,
      2.6,
      2.7,
      2.9,
      2.8,
      3.4,
      0.0,
      0.3,
      0.7,
      0.6,
      0.55,
      0.8,
      1.2,
      1.3,
      1.35,
      0.9,
      1.5,
      1.7,
      1.8,
      1.7,
      1.2,
      0.8,
      1.9,
      2.0,
      2.2,
      1.9,
      2.2,
      2.1,
      2.0,
      2.3,
      2.4,
      2.45,
      2.6,
      3.6,
      2.6,
      2.7,
      2.9,
      2.8,
      3.4,
    ],
    [
      4.0,
      3.3,
      2.7,
      1.6,
      0.55,
      0.8,
      1.2,
      1.3,
      1.35,
      0.9,
      1.5,
      1.7,
      1.8,
      1.7,
      1.2,
      0.8,
      1.9,
      2.0,
      2.2,
      1.9,
      2.2,
      2.1,
      2.0,
      2.3,
      2.4,
      2.45,
      2.6,
      3.6,
      2.6,
      2.7,
      2.9,
      2.8,
      3.4,
      0.0,
      0.3,
      0.7,
      0.6,
      0.55,
      0.8,
      1.2,
      1.3,
      1.35,
      0.9,
      1.5,
      1.7,
      1.8,
      1.7,
      1.2,
      0.8,
      1.9,
      2.0,
      2.2,
      1.9,
      2.2,
      2.1,
      2.0,
      2.3,
      2.4,
      2.45,
      2.6,
      3.6,
      2.6,
      2.7,
      2.9,
      2.8,
      3.4,
      0.0,
      0.3,
      0.7,
      0.6,
      0.55,
      0.8,
      1.2,
      1.3,
      1.35,
      0.9,
      1.5,
      1.7,
      1.8,
      1.7,
      1.2,
      0.8,
      1.9,
      2.0,
      2.2,
      1.9,
      2.2,
      2.1,
      2.0,
      2.3,
      2.4,
      2.45,
      2.6,
      3.6,
      2.6,
      2.7,
      2.9,
      2.8,
      3.4
    ]
  ];

  static final List<String> chartDropdownItems = [
    'Last 7 days',
    'Last month',
    'Last year'
  ];
  String actualDropdown = chartDropdownItems[0];
  int actualChart = 0;
  Future<DashboardModel> dashboardData;

  @override
  void initState() {
    super.initState();

    dashboardData = loadDashboardData();
  }

  Future<DashboardModel> loadDashboardData() async {
    var responses = await Future.wait([
      Requests.post(
          'https://ezbusinessmanagementuat.fisglobal.com/api/CardHolder/AltSearchCount',
          body: {
            'accountNumber': '',
            'email': '',
            'firstName': '',
            'institution': 1,
            'lastName': '',
            'phoneNumber': '',
            'ssn': '',
            'userName': ''
          },
          bodyEncoding: RequestBodyEncoding.JSON,
          timeoutSeconds: 60),
      Requests.post(
          'https://ezbusinessmanagementuat.fisglobal.com/api/DashboardData/GetInformation',
          body: {
            'pageNumber': 1,
            'pageSize': 3,
            'sortColumn': null,
            'sortDirection': 0
          },
          bodyEncoding: RequestBodyEncoding.JSON,
          timeoutSeconds: 60),
      Requests.post(
          'https://ezbusinessmanagementuat.fisglobal.com/api/CustomerService/GetAdminQueueMsgsCount',
          body: {
            'isSearch': false,
            'orderBy': null,
            'orderByDirection': 1,
            'pageNumber': 1,
            'pageSize': 10,
          },
          bodyEncoding: RequestBodyEncoding.JSON,
          timeoutSeconds: 60),
      Requests.get(
          'https://ezbusinessmanagementuat.fisglobal.com/api/CompanyDetails/GetCompanyDetailsForSearch_Count?LevelId=0&Corporation=&CompanyNumber=&CompanyName=&CompanyNickName=&Status=',
          bodyEncoding: RequestBodyEncoding.JSON,
          timeoutSeconds: 60),
      Requests.post(
          'https://ezbusinessmanagementuat.fisglobal.com/api/AdminUser/GetAdminUserSearch',
          body: {
            'adminUserId': 0,
            'companyId': '',
            'corpIns': 1,
            'dateFrom': '',
            'dateOption': 'P',
            'dateTo': '',
            'department': '',
            'email': '',
            'firstName': '',
            'institution': '',
            'lastName': '',
            'loginStatus': '',
            'mailCode': '',
            'pageNumber': 1,
            'pageSize': 25,
            'postalCode': '',
            'profileName': '',
            'sortColumn': '',
            'sortDirection': '',
            'state': '',
            'userName': '',
            'userStatus': ''
          },
          bodyEncoding: RequestBodyEncoding.JSON,
          timeoutSeconds: 60),
      Requests.post(
          'https://ezbusinessmanagementuat.fisglobal.com/api/AdminExpenseManagement/searchExpenseReportPageLoad',
          body: {
            'currentIndexexpensereport': 1,
            'levelId': EzSession.userLevel[0].levelId,
            'pageSizeexpensereport': 40,
            'sortColumn': 'ConfirmationNo',
            'sortDirection': 'ASC'
          },
          bodyEncoding: RequestBodyEncoding.JSON,
          timeoutSeconds: 60)
    ]);

    //first response
    responses[0].raiseForStatus();
    dynamic json = responses[0].json();

    List<CardholderCountModel> carholdersCount =
        List<CardholderCountModel>.from(
            json.map((model) => CardholderCountModel.fromJson(model)));

    //second response
    responses[1].raiseForStatus();
    dynamic json1 = responses[1].json();

    List<ImportantInfoModel> impInfo = List<ImportantInfoModel>.from(
        json1.map((model) => ImportantInfoModel.fromJson(model)));

    //Third response
    responses[2].raiseForStatus();
    //dynamic json2 = responses[2].json();

    //fourth response
    responses[3].raiseForStatus();
    dynamic json3 = responses[3].json();

    List<CompanyCountModel> companyCount = List<CompanyCountModel>.from(
        json3.map((model) => CompanyCountModel.fromJson(model)));

    //fifth response
    responses[4].raiseForStatus();
    dynamic json4 = responses[4].json();

    List<AdminUserModel> adminUserModel = List<AdminUserModel>.from(
        json4.map((model) => AdminUserModel.fromJson(model)));

    //sixth response
    responses[5].raiseForStatus();
    dynamic json5 = responses[5].json();

    List<ExpanseListModel> expanseList = List<ExpanseListModel>.from(
        json5.map((model) => ExpanseListModel.fromJson(model)));

    DashboardModel dashData = new DashboardModel();
    dashData.cardholders = carholdersCount.first;
    dashData.alertsCount = impInfo.length;
    dashData.msgCount = responses[2].json() as int;
    dashData.companyCount = companyCount.first.totalRecord;
    dashData.adminUsersCount =
        adminUserModel.length > 0 ? adminUserModel.first.totalRecords : 0;
    dashData.impInfos = impInfo;
    dashData.expanseList = expanseList;

    //EzSession.addCompanies(companyCount);
    EzSession.adminUsers = adminUserModel;

    return dashData;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        iconTheme: IconThemeData(
            color: EzBranding.getBrandingColor(
                'app-bar-font-color', Colors.white)),
        elevation: 2.0,
        backgroundColor:
            EzBranding.getBrandingColor('app-bar-bg-color', Colors.pink[900]),
        title: Text('eZBusiness',
            style: TextStyle(
                color: EzBranding.getBrandingColor(
                    'app-bar-font-color', Colors.white),
                fontWeight: FontWeight.w700,
                fontSize: 25.0)),
        actions: <Widget>[
          Container(
            margin: EdgeInsets.only(right: 8.0),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: <Widget>[
                Text(EzSession.getUserName(),
                    style: TextStyle(
                        color: EzBranding.getBrandingColor(
                            'app-bar-font-color', Colors.white),
                        fontWeight: FontWeight.w700,
                        fontSize: 14.0)),
                Icon(Icons.arrow_drop_down,
                    color: EzBranding.getBrandingColor(
                        'app-bar-font-color', Colors.white))
              ],
            ),
          )
        ],
      ),
      drawer: Drawer(
        child: ListView(
          padding: EdgeInsets.zero,
          children: const <Widget>[
            DrawerHeader(
              decoration: BoxDecoration(
                color: Colors.grey,
              ),
              child: Text(
                'Menu',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 25,
                ),
              ),
            ),
            ListTile(
              leading: Icon(Icons.message),
              title: Text('Messages'),
            ),
            ListTile(
              leading: Icon(Icons.account_circle),
              title: Text('Profile'),
            ),
            ListTile(
              leading: Icon(Icons.settings),
              title: Text('Settings'),
            ),
            ListTile(leading: Icon(Icons.logout), title: Text('Logout')),
          ],
        ),
      ),
      body: FutureBuilder<DashboardModel>(
        future: dashboardData,
        builder: (context, snapshot) {
          if (snapshot.hasData) {
            return StaggeredGridView.count(
              crossAxisCount: 2,
              crossAxisSpacing: 12.0,
              mainAxisSpacing: 12.0,
              padding: EdgeInsets.symmetric(horizontal: 16.0, vertical: 8.0),
              children: <Widget>[
                _buildTile(
                  Padding(
                    padding: const EdgeInsets.all(24.0),
                    child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: <Widget>[
                          Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: <Widget>[
                              Text('Cardholders',
                                  style: TextStyle(
                                      color: EzBranding.getBrandingColor(
                                          'dashboard-tile-subtext-color',
                                          Colors.black45),
                                      fontSize: 20.0)),
                              Text(
                                  snapshot.data.cardholders.totalRecord
                                      .toString(),
                                  style: TextStyle(
                                      color: EzBranding.getBrandingColor(
                                          'dashboard-tile-text-color',
                                          Colors.black),
                                      fontWeight: FontWeight.w700,
                                      fontSize: 25.0))
                            ],
                          ),
                          Material(
                              color: Colors.blue,
                              borderRadius: BorderRadius.circular(24.0),
                              child: Center(
                                  child: Padding(
                                padding: const EdgeInsets.all(16.0),
                                child: Icon(Icons.person,
                                    color: Colors.white, size: 25.0),
                              )))
                        ]),
                  ),
                  onTap: () => Navigator.of(context).push(
                      MaterialPageRoute(builder: (_) => CardholderlistPage())),
                ),
                _buildTile(
                    Padding(
                      padding: const EdgeInsets.all(24.0),
                      child: Column(
                          mainAxisAlignment: MainAxisAlignment.start,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: <Widget>[
                            Material(
                                color: Colors.teal,
                                shape: CircleBorder(),
                                child: Padding(
                                    padding: const EdgeInsets.all(16.0),
                                    child: Center(
                                      child: Icon(Icons.email,
                                          color: Colors.white, size: 25.0),
                                    ))),
                            Padding(padding: EdgeInsets.only(bottom: 16.0)),
                            Center(
                                child: Text(snapshot.data.msgCount.toString(),
                                    style: TextStyle(
                                        color: EzBranding.getBrandingColor(
                                            'dashboard-tile-text-color',
                                            Colors.black),
                                        fontWeight: FontWeight.w700,
                                        fontSize: 25.0))),
                            Center(
                                child: Text('Messages',
                                    style: TextStyle(
                                        color: EzBranding.getBrandingColor(
                                            'dashboard-tile-subtext-color',
                                            Colors.black45),
                                        fontSize: 20.0))),
                          ]),
                    ), onTap: () {
                  Navigator.of(context).push(
                      MaterialPageRoute(builder: (_) => MessageListPage()));
                }),
                _buildTile(
                  Padding(
                    padding: const EdgeInsets.all(24.0),
                    child: Column(
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          Material(
                              color: Colors.amber,
                              shape: CircleBorder(),
                              child: Padding(
                                  padding: EdgeInsets.all(16.0),
                                  child: Center(
                                    child: Icon(Icons.notifications,
                                        color: Colors.white, size: 25.0),
                                  ))),
                          Padding(padding: EdgeInsets.only(bottom: 16.0)),
                          Center(
                              child: Text(
                            snapshot.data.alertsCount.toString(),
                            style: TextStyle(
                                color: EzBranding.getBrandingColor(
                                    'dashboard-tile-text-color', Colors.black),
                                fontWeight: FontWeight.w700,
                                fontSize: 25.0),
                          )),
                          Center(
                              child: Text('Alerts',
                                  style: TextStyle(
                                      color: EzBranding.getBrandingColor(
                                          'dashboard-tile-subtext-color',
                                          Colors.black45),
                                      fontSize: 20.0))),
                        ]),
                  ),
                  onTap: () => Navigator.of(context).push(MaterialPageRoute(
                      builder: (_) =>
                          ImpInfoListPage(impInfos: snapshot.data.impInfos))),
                ),
                _buildTile(
                  Padding(
                      padding: const EdgeInsets.all(24.0),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: <Widget>[
                              Column(
                                mainAxisAlignment: MainAxisAlignment.start,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: <Widget>[
                                  Text('Payments',
                                      style: TextStyle(
                                          color: EzBranding.getBrandingColor(
                                              'dashboard-tile-subtext-color',
                                              Colors.black45),
                                          fontSize: 20.0)),
                                  Text('\$23K',
                                      style: TextStyle(
                                          color: EzBranding.getBrandingColor(
                                              'dashboard-tile-text-color',
                                              Colors.black),
                                          fontWeight: FontWeight.w700,
                                          fontSize: 25.0)),
                                ],
                              ),
                              DropdownButton(
                                  isDense: true,
                                  value: actualDropdown,
                                  onChanged: (String value) => setState(() {
                                        actualDropdown = value;
                                        actualChart =
                                            chartDropdownItems.indexOf(
                                                value); // Refresh the chart
                                      }),
                                  items: chartDropdownItems.map((String title) {
                                    return DropdownMenuItem(
                                      value: title,
                                      child: Text(title,
                                          style: TextStyle(
                                              color: Colors.blue,
                                              fontWeight: FontWeight.w400,
                                              fontSize: 14.0)),
                                    );
                                  }).toList())
                            ],
                          ),
                          Padding(padding: EdgeInsets.only(bottom: 4.0)),
                          Sparkline(
                            data: charts[actualChart],
                            lineWidth: 3.0,
                            lineColor: EzBranding.getBrandingColor(
                                'app-bar-bg-color', Colors.pink[900]),
                            pointsMode: PointsMode.last,
                            fillMode: FillMode.below,
                            fillGradient: new LinearGradient(
                              begin: Alignment.topCenter,
                              end: Alignment.bottomCenter,
                              colors: [
                                EzBranding.getBrandingColor(
                                    'app-bar-bg-color', Colors.pink[800]),
                                EzBranding.getBrandingColor(
                                    'dashboard-graph-bottom-color', Colors.pink)
                              ],
                            ),
                          )
                        ],
                      )),
                ),
                _buildTile(
                  Padding(
                    padding: const EdgeInsets.all(24.0),
                    child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: <Widget>[
                          Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: <Widget>[
                              Text('Expanse Reports',
                                  style: TextStyle(
                                      color: EzBranding.getBrandingColor(
                                          'dashboard-tile-subtext-color',
                                          Colors.black45),
                                      fontSize: 20.0)),
                              Text(
                                  snapshot.data.expanseList.length == 0
                                      ? '0'
                                      : snapshot
                                          .data.expanseList.first.totalcount
                                          .toString(),
                                  style: TextStyle(
                                      color: EzBranding.getBrandingColor(
                                          'dashboard-tile-text-color',
                                          Colors.black),
                                      fontWeight: FontWeight.w700,
                                      fontSize: 25.0))
                            ],
                          ),
                          Material(
                              color: Colors.red,
                              borderRadius: BorderRadius.circular(24.0),
                              child: Center(
                                  child: Padding(
                                padding: EdgeInsets.all(16.0),
                                child: Icon(Icons.receipt,
                                    color: Colors.white, size: 25.0),
                              )))
                        ]),
                  ),
                  onTap: () => Navigator.of(context).push(MaterialPageRoute(
                      builder: (_) =>
                          ExplistPage(expList: snapshot.data.expanseList))),
                  //onTap: () {},
                ),
                _buildTile(
                  Padding(
                    padding: const EdgeInsets.all(24.0),
                    child: Column(
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          Material(
                              color: Colors.brown,
                              shape: CircleBorder(),
                              child: Padding(
                                  padding: const EdgeInsets.all(16.0),
                                  child: Center(
                                    child: Icon(Icons.apartment,
                                        color: Colors.white, size: 25.0),
                                  ))),
                          Padding(padding: EdgeInsets.only(bottom: 16.0)),
                          Center(
                              child: Text(snapshot.data.companyCount.toString(),
                                  style: TextStyle(
                                      color: EzBranding.getBrandingColor(
                                          'dashboard-tile-text-color',
                                          Colors.black),
                                      fontWeight: FontWeight.w700,
                                      fontSize: 25.0))),
                          Center(
                              child: Text('Companies',
                                  style: TextStyle(
                                      color: EzBranding.getBrandingColor(
                                          'dashboard-tile-subtext-color',
                                          Colors.black45),
                                      fontSize: 20.0))),
                        ]),
                  ),
                ),
                _buildTile(
                  Padding(
                    padding: const EdgeInsets.all(24.0),
                    child: Column(
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          Material(
                              color: Colors.purple,
                              shape: CircleBorder(),
                              child: Padding(
                                  padding: EdgeInsets.all(16.0),
                                  child: Center(
                                    child: Icon(Icons.verified_user,
                                        color: Colors.white, size: 25.0),
                                  ))),
                          Padding(padding: EdgeInsets.only(bottom: 16.0)),
                          Center(
                              child: Text(
                                  snapshot.data.adminUsersCount.toString(),
                                  style: TextStyle(
                                      color: EzBranding.getBrandingColor(
                                          'dashboard-tile-text-color',
                                          Colors.black),
                                      fontWeight: FontWeight.w700,
                                      fontSize: 25.0))),
                          Center(
                              child: Text('Admins',
                                  style: TextStyle(
                                      color: EzBranding.getBrandingColor(
                                          'dashboard-tile-subtext-color',
                                          Colors.black45),
                                      fontSize: 20.0))),
                        ]),
                  ),
                  onTap: () => Navigator.of(context)
                      .push(MaterialPageRoute(builder: (_) => AdminlistPage())),
                ),
              ],
              staggeredTiles: [
                StaggeredTile.extent(2, 110.0),
                StaggeredTile.extent(1, 180.0),
                StaggeredTile.extent(1, 180.0),
                StaggeredTile.extent(2, 220.0),
                StaggeredTile.extent(2, 110.0),
                StaggeredTile.extent(1, 180.0),
                StaggeredTile.extent(1, 180.0),
              ],
            );
          } else if (snapshot.hasError) {
            return Text('${snapshot.error}');
          }

          return Center(
            child: CircularProgressIndicator(),
          );
        },
      ),
      bottomNavigationBar: Container(
        height: 55.0,
        child: BottomAppBar(
          color:
              EzBranding.getBrandingColor('app-bar-bg-color', Colors.pink[900]),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: <Widget>[
              IconButton(
                icon: Icon(Icons.home,
                    color: EzBranding.getBrandingColor(
                        'app-bar-font-color', Colors.white)),
                onPressed: () {},
              ),
              IconButton(
                icon: Icon(Icons.bar_chart,
                    color: EzBranding.getBrandingColor(
                        'app-bar-font-color', Colors.white)),
                onPressed: () {},
              ),
              IconButton(
                icon: Icon(Icons.account_box,
                    color: EzBranding.getBrandingColor(
                        'app-bar-font-color', Colors.white)),
                onPressed: () {},
              ),
              IconButton(
                icon: Icon(Icons.settings,
                    color: EzBranding.getBrandingColor(
                        'app-bar-font-color', Colors.white)),
                onPressed: () {},
              )
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildTile(Widget child, {Function() onTap}) {
    return Material(
        elevation: 10.0,
        color: EzBranding.getBrandingColor(
            'dashboard-tile-bg-color', Colors.pink[900]),
        borderRadius: BorderRadius.circular(12.0),
        shadowColor: EzBranding.getBrandingColor('dashboard-tile-shadow-color',
            Color(0x802196F3)), //Color(0x802196F3),
        child: InkWell(
            // Do onTap() if it isn't null, otherwise do print()
            onTap: onTap != null
                ? () => onTap()
                : () {
                    print('Not set yet');
                  },
            child: child));
  }
}
