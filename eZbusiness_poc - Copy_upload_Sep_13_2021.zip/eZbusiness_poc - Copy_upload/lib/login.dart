import 'package:flutter/material.dart';
import 'package:flutter_app_sample/Model/ConfigKeyModel.dart';
import 'package:flutter_app_sample/Model/LoginModel.dart';
import 'package:flutter_app_sample/Model/LoginUserDetailModel.dart';
import 'package:flutter_app_sample/Service/eZBranding.dart';
import 'package:local_auth/local_auth.dart';
import 'package:local_auth/auth_strings.dart';
import 'package:requests/requests.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'Service/eZSession.dart';
import 'dashboard.dart';

class LoginPage extends StatefulWidget {
  LoginPage({Key key, this.title}) : super(key: key);

  // This widget is the home page of your application. It is stateful, meaning
  // that it has a State object (defined below) that contains fields that affect
  // how it looks.

  // This class is the configuration for the state. It holds the values (in this
  // case the title) provided by the parent (in this case the App widget) and
  // used by the build method of the State. Fields in a Widget subclass are
  // always marked "final".

  final String title;

  @override
  _LoginPageState createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  int _state = 0;
  TextStyle style = TextStyle(fontFamily: 'Montserrat', fontSize: 20.0);
  TextEditingController emailController = new TextEditingController();
  TextEditingController passwordController = new TextEditingController();

  Widget setupChildButton() {
    if (_state == 0) {
      return Text("Login",
          textAlign: TextAlign.center,
          style:
              style.copyWith(color: Colors.white, fontWeight: FontWeight.bold));
    } else {
      return CircularProgressIndicator(
        valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
      );
    }
  }

  Future<bool> _checkBiometric() async {
    final LocalAuthentication auth = LocalAuthentication();
    bool canCheckBiometrics = false;
    try {
      canCheckBiometrics = await auth.canCheckBiometrics;
    } catch (e) {
      print("error biome trics $e");
    }

    print("biometric is available: $canCheckBiometrics");

    List<BiometricType> availableBiometrics;
    try {
      availableBiometrics = await auth.getAvailableBiometrics();
    } catch (e) {
      print("error enumerate biometrics $e");
    }

    print("following biometrics are available");
    if (availableBiometrics.isNotEmpty) {
      availableBiometrics.forEach((ab) {
        print("\ttech: $ab");
      });
    } else {
      print("no biometrics are available");
    }

    bool authenticated = false;
    try {
      SharedPreferences prefs = await SharedPreferences.getInstance();
      var username = prefs.getString('username');
      authenticated = await auth.authenticateWithBiometrics(
          localizedReason: 'Registered eZBusiness user: $username',
          useErrorDialogs: true,
          stickyAuth: false,
          androidAuthStrings:
              AndroidAuthMessages(signInTitle: "Login to eZBusiness"));
    } catch (e) {
      print("error using biometric auth: $e");
    }

    print("authenticated: $authenticated");
    return authenticated;
  }

  Future _loginUser(String username, String password, bool save) async {
    var r = await Requests.post(
        'https://ezbusinessmanagementuat.fisglobal.com/api/Login/ValidateUsername',
        body: {
          'Username': username, //emailController.text,
          'Password': password, //passwordController.text,
          'approvalData': '',
          'isForgotPassword': false,
          'devicePrint': ''
        },
        bodyEncoding: RequestBodyEncoding.JSON,
        timeoutSeconds: 60);

    r.raiseForStatus();
    dynamic json = r.json();
    print(json);

    var loginModel = LoginModel.fromJson(json);

    if (loginModel.state == 18) {
      if (save) {
        SharedPreferences prefs = await SharedPreferences.getInstance();
        prefs.setString('username', username);
        prefs.setString('userpass', password);
      }

      var responses = await Future.wait([
        Requests.get(
            'https://ezbusinessmanagementuat.fisglobal.com/api/XsrfToken'),
        Requests.get(
            'https://ezbusinessmanagementuat.fisglobal.com/api/DashboardData/UserLevel'),
        Requests.get(
            'https://ezbusinessmanagementuat.fisglobal.com/api/DashboardData/loginuserDetail'),
        Requests.post(
            'https://ezbusinessmanagementuat.fisglobal.com/api/Config/GetConfigKeyValuesByUserId',
            body: {'tagName': 'AppThemeSettings'},
            bodyEncoding: RequestBodyEncoding.JSON,
            timeoutSeconds: 60)
      ]);

      responses[0].raiseForStatus();
      responses[1].raiseForStatus();
      responses[2].raiseForStatus();
      responses[3].raiseForStatus();

      var cookies = await Requests.getStoredCookies(Requests.getHostname(
          'https://ezbusinessmanagementuat.fisglobal.com/api/XsrfToken'));

      if (cookies.containsKey('XSRF-REQUEST-TOKEN')) {
        EzSession.setXsrfToken(cookies['XSRF-REQUEST-TOKEN']);
      }

      EzSession.userLevel = List<UserLevelModel>.from(
          responses[1].json().map((model) => UserLevelModel.fromJson(model)));

      EzSession.loginUserDetail = List<LoginUserDetailModel>.from(responses[2]
          .json()
          .map((model) => LoginUserDetailModel.fromJson(model)));

      EzBranding.setBranding(List<ConfigKeyModel>.from(
          responses[3].json().map((model) => ConfigKeyModel.fromJson(model))));

      EzSession.setLoginStatus(true, EzSession.loginUserDetail[0].username);

      setState(() {
        _state = 0;
      });

      Navigator.of(context)
          .push(MaterialPageRoute(builder: (_) => DashboardPage()));
    } else {
      setState(() {
        _state = 0;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    // This method is rerun every time setState is called, for instance as done
    // by the _incrementCounter method above.
    //
    // The Flutter framework has been optimized to make rerunning build methods
    // fast, so that you can just rebuild anything that needs updating rather
    // than having to individually change instances of widgets.

    final emailField = TextField(
      controller: emailController,
      obscureText: false,
      style: style,
      decoration: InputDecoration(
          contentPadding: EdgeInsets.fromLTRB(20.0, 15.0, 20.0, 15.0),
          hintText: "Username",
          border:
              OutlineInputBorder(borderRadius: BorderRadius.circular(32.0))),
    );

    final passwordField = TextField(
      controller: passwordController,
      obscureText: true,
      style: style,
      decoration: InputDecoration(
          contentPadding: EdgeInsets.fromLTRB(20.0, 15.0, 20.0, 15.0),
          hintText: "Password",
          border:
              OutlineInputBorder(borderRadius: BorderRadius.circular(32.0))),
    );

    final loginButon = Material(
      elevation: 5.0,
      borderRadius: BorderRadius.circular(30.0),
      color: Colors.pink[900],
      child: MaterialButton(
        minWidth: MediaQuery.of(context).size.width,
        padding: EdgeInsets.fromLTRB(20.0, 15.0, 20.0, 15.0),
        //onPressed: () {},
        onPressed: () async {
          setState(() {
            _state = 1;
          });

          EzSession.clear();
          await _loginUser(emailController.text, passwordController.text, true);
        },
        child: setupChildButton(),
      ),
    );

    return Scaffold(
        body: SingleChildScrollView(
      child: Center(
        child: Container(
          color: Colors.white,
          child: Padding(
            padding: const EdgeInsets.all(36.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                SizedBox(
                  height: 155.0,
                  child: Image.asset(
                    "images/logo.png",
                    fit: BoxFit.contain,
                  ),
                ),
                SizedBox(height: 45.0),
                emailField,
                SizedBox(height: 25.0),
                passwordField,
                SizedBox(
                  height: 35.0,
                ),
                loginButon,
                SizedBox(
                  height: 35.0,
                ),
                Container(
                  padding: EdgeInsets.all(20),
                  child: Center(
                    child: Text('OR'),
                  ),
                ),
                SizedBox(
                  height: 15.0,
                ),
                Container(
                  padding: EdgeInsets.all(20),
                  child: Center(
                    child: MaterialButton(
                        minWidth: MediaQuery.of(context).size.width,
                        padding: EdgeInsets.fromLTRB(20.0, 15.0, 20.0, 15.0),
                        child: Icon(
                          Icons.fingerprint,
                          color: Colors.grey[500],
                          size: 155.0,
                        ),
                        onPressed: () async {
                          setState(() {
                            _state = 1;
                          });

                          EzSession.clear();

                          if (await _checkBiometric()) {
                            SharedPreferences prefs =
                                await SharedPreferences.getInstance();
                            var username = prefs.getString('username');
                            var password = prefs.getString('userpass');

                            if (username != null &&
                                username.length > 0 &&
                                password != null &&
                                password.length > 0) {
                              await _loginUser(username, password, false);
                            } else {
                              setState(() {
                                _state = 0;
                              });
                            }
                          } else {
                            setState(() {
                              _state = 0;
                            });
                          }
                        }),
                  ),
                ),
                SizedBox(
                  height: 25.0,
                ),
              ],
            ),
          ),
        ),
      ),
    ));
  }
}
