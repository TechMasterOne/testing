import 'Model/ImportantInfoModel.dart';
import 'package:flutter/material.dart';
import 'package:flutter_html/flutter_html.dart';

class ImpInfoDetailPage extends StatelessWidget {
  final ImportantInfoModel importantInfo;
  ImpInfoDetailPage({Key key, this.importantInfo}) : super(key: key);
  @override
  Widget build(BuildContext context) {
    final topContentText = Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        SizedBox(height: 50.0),
        Icon(
          Icons.notifications,
          color: Colors.white,
          size: 40.0,
        ),
        Container(
          width: 90.0,
          child: new Divider(color: Colors.green),
        ),
        SizedBox(height: 10.0),
        Text(
          importantInfo.messageSubject,
          style: TextStyle(color: Colors.white, fontSize: 35.0),
        ),
        SizedBox(height: 10.0),
        Text(
          importantInfo.sendDate.substring(0, 10),
          style: TextStyle(color: Colors.white, fontSize: 15.0),
        )
      ],
    );

    final topContent = Stack(
      children: <Widget>[
        Container(
          height: 300,
          padding: EdgeInsets.all(30.0),
          width: MediaQuery.of(context).size.width,
          decoration: BoxDecoration(color: Color.fromRGBO(58, 66, 86, .9)),
          child: Center(
            child: topContentText,
          ),
        ),
        Positioned(
          left: 8.0,
          top: 60.0,
          child: InkWell(
            onTap: () {
              Navigator.pop(context);
            },
            child: Icon(Icons.arrow_back, color: Colors.white),
          ),
        )
      ],
    );

    final bottomContentText = Html(
      data: importantInfo.messageContent,
    );
    final readButton = Container(
        padding: EdgeInsets.symmetric(vertical: 16.0),
        width: MediaQuery.of(context).size.width,
        child: RaisedButton(
          onPressed: () => {},
          color: Color.fromRGBO(58, 66, 86, 1.0),
          child: Text("Mark as " + importantInfo.status,
              style: TextStyle(color: Colors.white)),
        ));
    final bottomContent = Container(
      width: MediaQuery.of(context).size.width,
      padding: EdgeInsets.all(40.0),
      child: Center(
        child: Column(
          children: <Widget>[bottomContentText, readButton],
        ),
      ),
    );

    return Scaffold(
      body: Column(
        children: <Widget>[topContent, bottomContent],
      ),
    );
  }
}
